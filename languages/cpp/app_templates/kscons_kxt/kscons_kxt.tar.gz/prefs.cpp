%{CPP_TEMPLATE}

#include "prefs.h"
#include <kdebug.h>

Prefs::Prefs()
	: Prefs_base()
{
// debugging :
//	kWarning()<<"creating a pref dialog"<<endl;
}

