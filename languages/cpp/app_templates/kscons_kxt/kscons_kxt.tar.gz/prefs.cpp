%{CPP_TEMPLATE}

#include "prefs.h"
#include <kdebug.h>

Prefs::Prefs()
	: Prefs_base()
{
// debugging :
//	kdWarning()<<"creating a pref dialog"<<endl;
}

