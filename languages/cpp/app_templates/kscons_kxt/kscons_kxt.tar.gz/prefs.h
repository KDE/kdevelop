%{H_TEMPLATE}

#include "prefs-base.h"


class Prefs : public Prefs_base
{
	public:
		Prefs();
};

