/***************************************************************************
                          kpenbrushdlg.cpp  -  description                              
                             -------------------                                         
    begin                : Fri Jul 23 1999                                           
    copyright            : (C) 1999 by Ralf Nolden                         
    email                : Ralf.Nolden@post.rwth-aachen.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/

#include "kpenbrushdlg.h"
#include <qwhatsthis.h>
#include <kapp.h>

KPenBrushDlg::KPenBrushDlg(int curr, QWidget *parent, const char *name) : QDialog(parent,name,true,WStyle_ContextHelp){
	initDialog();
  QWhatsThis::add(width_spbox,i18n("Select brush width"));

	width_spbox->setValue(curr);
	connect(default_btn, SIGNAL(clicked()), this, SLOT(slotDefault()));
	connect(ok_btn, SIGNAL(clicked()), this, SLOT(accept()));
	connect(cancel_btn, SIGNAL(clicked()), this, SLOT(reject()));
}

KPenBrushDlg::~KPenBrushDlg(){
}

void KPenBrushDlg::slotDefault(){
  width_spbox->setValue(3);
}











