/***************************************************************************
                          resource.h  -  description
                             -------------------
    begin                : Mon Jan 31 11:05:05 CET 2000
    copyright            : (C) 2000 by Ralf Nolden
    email                : Ralf.Nolden@post.rwth-aachen.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef RESOURCE_H
#define RESOURCE_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

///////////////////////////////////////////////////////////////////
// resource.h  -- contains macros used for commands


///////////////////////////////////////////////////////////////////
// COMMAND VALUES FOR MENUBAR AND TOOLBAR ENTRIES


///////////////////////////////////////////////////////////////////
// File-menu entries
#define ID_FILE_NEW                 10010
#define ID_FILE_OPEN                10020
#define ID_FILE_OPEN_RECENT         10030
#define ID_FILE_CLOSE               10040

#define ID_FILE_SAVE                10050
#define ID_FILE_SAVE_AS             10060

#define ID_FILE_PRINT               10070

#define ID_FILE_QUIT                10080

///////////////////////////////////////////////////////////////////
// Edit-menu entries
#define ID_EDIT_UNDO                11010
#define ID_EDIT_COPY                11020
#define ID_EDIT_CUT                 11030
#define ID_EDIT_PASTE               11040
#define ID_EDIT_CLEAR_ALL           11050

///////////////////////////////////////////////////////////////////
// Pen-menu entries
#define ID_PEN_COLOR                14010
#define ID_PEN_BRUSH                14020

///////////////////////////////////////////////////////////////////
// Draw-menu entries
#define ID_DRAW_FIND                15010
#define ID_DRAW_FREEHAND            15020
#define ID_DRAW_LINE                15030
#define ID_DRAW_RECT                15040
#define ID_DRAW_RECT_FILL           15050
#define ID_DRAW_CIRCLE              15060
#define ID_DRAW_CIRCLE_FILL         15070
#define ID_DRAW_ELLIPSE             15080
#define ID_DRAW_ELLIPSE_FILL        15090
#define ID_DRAW_SPRAY               15100
#define ID_DRAW_FILL                15110
#define ID_DRAW_ERASE               15120

///////////////////////////////////////////////////////////////////
// View-menu entries                    
#define ID_VIEW_TOOLBAR             12010
#define ID_VIEW_STATUSBAR           12020

///////////////////////////////////////////////////////////////////
// Window-menu entries
#define ID_WINDOW_NEW_WINDOW        13010
#define ID_WINDOW_CASCADE   		    13020
#define ID_WINDOW_TILE			        13030

///////////////////////////////////////////////////////////////////
// Help-menu entries
#define ID_HELP_CONTENTS            1002
#define ID_HELP_WHATS_THIS					1003
///////////////////////////////////////////////////////////////////
// General application values
#define ID_STATUS_MSG               1001
#define TOOLS_TOOLBAR               1
#endif // RESOURCE_H
