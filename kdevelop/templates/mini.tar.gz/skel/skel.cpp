#include "skel.h"

Skel::Skel(QWidget*parent,const char* name):QWidget(parent,name){
}
Skel::~Skel(){
}
