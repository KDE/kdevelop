#include "|NAMELITTLE|.h"

|NAME|::|NAME|(QWidget*parent,const char* name):QWidget(parent,name){
}
|NAME|::~|NAME|(){
}
