#ifndef SKEL_H
#define SKEL_H

#include <kapp.h>
#include <qwidget.h>

class Skel : public QWidget {
  Q_OBJECT 
public: 
  /** construtor */
  Skel(QWidget*parent=0,const char* name=0); 
  /** destructor */
  ~Skel();  
};
#endif
