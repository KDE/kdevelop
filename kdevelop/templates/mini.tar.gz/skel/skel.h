#ifndef |NAMEBIG|_H
#define |NAMEBIG|_H

#include <kapp.h>
#include <qwidget.h>

class |NAME| : public QWidget {
  Q_OBJECT 
public: 
  /** construtor */
  |NAME|(QWidget*parent=0,const char* name=0); 
  /** destructor */
  ~|NAME|();  
};
#endif
