
#ifndef |NAMEBIG|_H
#define |NAMEBIG|_H

#include <kapp.h>
#include <qwidget.h>

/** |NAME| is the base class of the project */
class |NAME| : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    |NAME|(QWidget* parent=0, const char *name=0);
    /** destructor */
    ~|NAME|();
};

#endif
