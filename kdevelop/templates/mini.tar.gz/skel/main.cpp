#include "|NAMELITTLE|.h"
 
int main(int argc, char* argv[]) { 
  KApplication a(argc,argv,"|NAMELITTLE|");  
  
  |NAME|* |NAMELITTLE| = new |NAME|;
  a.setMainWidget(|NAMELITTLE|);
  |NAMELITTLE|->show();  
  return a.exec();
}
