#include "skel.h"
 
int main(int argc, char* argv[]) { 
  KApplication a(argc,argv,"skel");  
  
  Skel* skel = new Skel;
  a.setMainWidget(skel);
  skel->show();  
  return a.exec();
}
