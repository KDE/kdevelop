
#include "|NAME|Doc.h"

@implementation |NAME|Doc

- init
{
	[super init];
	modified = NO;
	return self;
}

- (void) dealloc
{
	[super dealloc];
	return;
}

- (void) newDoc
{
}

- (BOOL) save
{
	return YES;
}

- (BOOL) saveAs: (NSString *) filename
{
	return YES;
}

- (BOOL) load: (NSString *) filename
{
	[self emit: @"documentChanged"];
	return YES;
}

- (BOOL) isModified
{
	return modified;
}

@end
