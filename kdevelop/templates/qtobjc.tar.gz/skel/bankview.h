
#ifndef |NAMEBIG|VIEW_H
#define |NAMEBIG|VIEW_H

#include <Foundation/NSObject.h>

// include files for QT
#include <qtobjc/QWidget.h>

// application specific includes
#include "|NAME|Doc.h"

/**
 * This class provides an incomplete base for your application view. 
 */

@interface |NAME|View : QWidget
    - initWithParent: (QWidget *) parent doc: (|NAME|Doc*) doc;
    - (void) dealloc;

//  slots:
    - (void) slotDocumentChanged;
@end

#endif
