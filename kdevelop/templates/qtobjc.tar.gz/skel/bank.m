
#include "|NAME|.h"
#include "filesave.xpm"
#include "fileopen.xpm"
#include "filenew.xpm"

@implementation |NAME|

- init
{
	[super init];
	[self setCaption: @"|NAME| "];

  ///////////////////////////////////////////////////////////////////
  // call inits to invoke all other construction parts
	[self initMenuBar];
	[self initToolBar];
	[self initStatusBar];

	[self initDoc];
	[self initView];
	
	return self;
}

- (void) dealloc
{
	[super dealloc];
	return;
}

- (void) initMenuBar
{
  ///////////////////////////////////////////////////////////////////
  // MENUBAR

  ///////////////////////////////////////////////////////////////////
  // menuBar entry fileMenu

  fileMenu = [[QPopupMenu alloc] init];
  [fileMenu insertItem: @"&New" receiver: self slot: @"slotFileNew" accel: CTRL+Key_N identifier: ID_FILE_NEW];
  [fileMenu insertItem: @"&Open..." receiver: self slot: @"slotFileOpen" accel: CTRL+Key_O identifier: ID_FILE_OPEN];
  [fileMenu insertSeparator];
  [fileMenu insertItem: @"&Save" receiver: self slot: @"slotFileSave" accel: CTRL+Key_S identifier: ID_FILE_SAVE];
  [fileMenu insertItem: @"Save &as..." receiver: self slot: @"slotFileSaveAs" accel: 0 identifier: ID_FILE_SAVE_AS];
  [fileMenu insertItem: @"&Close" receiver: self slot: @"slotFileClose" accel: CTRL+Key_W identifier: ID_FILE_CLOSE];
  [fileMenu insertSeparator];
  [fileMenu insertItem: @"&Print" receiver: self slot: @"slotFilePrint" accel: CTRL+Key_P identifier: ID_FILE_PRINT];
  [fileMenu insertSeparator];
  [fileMenu insertItem: @"E&xit" receiver: self slot: @"slotFileQuit" accel: CTRL+Key_Q identifier: ID_FILE_QUIT];

  ///////////////////////////////////////////////////////////////////
  // menuBar entry editMenu
  editMenu = [[QPopupMenu alloc] init];
  [editMenu insertItem: @"Cu&t" receiver: self slot: @"slotEditCut" accel: CTRL+Key_X identifier: ID_EDIT_CUT];
  [editMenu insertItem: @"&Copy" receiver: self slot: @"slotEditCopy" accel: CTRL+Key_C identifier: ID_EDIT_COPY];
  [editMenu insertItem: @"&Paste" receiver: self slot: @"slotEditPaste" accel: CTRL+Key_V identifier: ID_EDIT_PASTE];


  ///////////////////////////////////////////////////////////////////
  // menuBar entry viewMenu
  viewMenu = [[QPopupMenu alloc] init];
  [viewMenu setCheckable: YES];
  [viewMenu insertItem: @"Tool&bar" receiver: self slot: @"slotViewToolBar" accel: 0 identifier: ID_VIEW_TOOLBAR];
  [viewMenu insertItem: @"&Statusbar" receiver: self slot: @"slotViewStatusBar" accel: 0 identifier: ID_VIEW_STATUSBAR];

  [viewMenu setItemChecked: ID_VIEW_TOOLBAR check: YES];
  [viewMenu setItemChecked: ID_VIEW_STATUSBAR check: YES];
  ///////////////////////////////////////////////////////////////////
  // EDIT YOUR APPLICATION SPECIFIC MENUENTRIES HERE

  ///////////////////////////////////////////////////////////////////
  // menuBar entry helpMenu
  helpMenu = [[QPopupMenu alloc] init];
  [helpMenu insertItem: @"About..." receiver: self slot: @"slotHelpAbout" accel: 0 identifier: ID_HELP_ABOUT];


  ///////////////////////////////////////////////////////////////////
  // MENUBAR CONFIGURATION
  // set menuBar() the current menuBar

  [[self menuBar] insertPopupItem: @"&File" popup: fileMenu];
  [[self menuBar] insertPopupItem: @"&Edit" popup: editMenu];
  [[self menuBar] insertPopupItem: @"&View" popup: viewMenu];
  [[self menuBar] insertSeparator];
  [[self menuBar] insertPopupItem: @"&Help" popup: helpMenu];

  ///////////////////////////////////////////////////////////////////
  // CONNECT THE SUBMENU SLOTS WITH SIGNALS

  [self connect: fileMenu signal: @"highlighted(int)" slot: @"statusCallback:"];
  [self connect: editMenu signal: @"highlighted(int)" slot: @"statusCallback:"];
  [self connect: viewMenu signal: @"highlighted(int)" slot: @"statusCallback:"];
  [self connect: helpMenu signal: @"highlighted(int)" slot: @"statusCallback:"];

}

- (void) initToolBar
{
 ///////////////////////////////////////////////////////////////////
  // TOOLBAR
  QPixmap *openIcon, *saveIcon, *newIcon;
  QToolButton *fileNew, *fileOpen, *fileSave;

  fileToolbar = [[QToolBar alloc] initWithParent: self name: @"file operations"];

  newIcon = [[QPixmap alloc] initFromXpm: filenew];
  fileNew = [[QToolButton alloc] initWithPixmap: newIcon label: @"New File" groupText: @"" receiver: self
                                         slot: @"slotFileNew" parent: fileToolbar];

  openIcon = [[QPixmap alloc] initFromXpm: fileopen];
  fileOpen = [[QToolButton alloc] initWithPixmap: openIcon label: @"Open File" groupText: @"" receiver: self
                                          slot: @"slotFileOpen" parent: fileToolbar];

  saveIcon = [[QPixmap alloc] initFromXpm: filesave];
  fileSave = [[QToolButton alloc] initWithPixmap: saveIcon label: @"Save File" groupText: @"" receiver: self
                                          slot: @"slotFileSave" parent: fileToolbar];


  [fileToolbar addSeparator];
  [QWhatsThis whatsThisButton: fileToolbar];
  [QWhatsThis add: fileNew text: @"Click this button to create a new file.\n\n"
                  @"You can also select the New command from the File menu."];
  [QWhatsThis add: fileOpen text: @"Click this button to open a new file.\n\n"
                  @"You can also select the Open command from the File menu."];
  [QWhatsThis add: fileSave text: @"Click this button to save the file you are "
                  @"editing. You will be prompted for a file name.\n\n"
                  @"You can also select the Save command from the File menu."];

}

- (void) initStatusBar
{
  ///////////////////////////////////////////////////////////////////
  //STATUSBAR
  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT] milliSeconds: 2000];
}

- (void) initDoc
{
   doc=[[|NAME|Doc alloc] init];
}

- (void) initView
{
  ////////////////////////////////////////////////////////////////////
  // set the main widget here
  view=[[|NAME|View alloc] initWithParent: self doc: doc];
  [self setCentralWidget: view];
}

- (BOOL) queryExit
{
  int exit=[QMessageBox information: self caption: @"Quit..."
                                    text: @"Do your really want to quit?"
                                    button0: Ok button1: Cancel];

  if (exit==1)
  {

  }
  else
  {

  };

  return (exit==1);
}



- (void) slotFileNew
{
  [[self statusBar] message: @"Creating new file..."];
  [doc newDoc];
  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotFileOpen
{
  NSString * message;
  NSString * fileName;
  	
  [[self statusBar] message: @"Opening file..."];

  fileName = [QFileDialog getOpenFileName: 0 filter: 0 parent: self];
  if (![fileName isEqualToString: @""])
  {
    [doc load: fileName];
    [self setCaption: fileName];
    message = [NSString stringWithFormat: @"Loaded document: %@", fileName];
    [[self statusBar] message: message milliSeconds: 2000];
  }
  else
  {
    [[self statusBar] message: @"Opening aborted" milliSeconds: 2000];
  }
}

- (void) slotFileSave
{
  [[self statusBar]  message: @"Saving file..."];
  [doc save];
  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotFileSaveAs
{
  NSString * fn;
  [[self statusBar] message: @"Saving file under new filename..."];
  fn = [QFileDialog getSaveFileName: 0 filter: 0 parent: self];
  if (![fn isEqualToString: @""])
  {
    [doc saveAs: fn];
  }
  else
  {
    [[self statusBar] message: @"Saving aborted" milliSeconds: 2000];
  }

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotFileClose
{
  [[self statusBar] message: @"Closing file..."];

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotFilePrint
{
  QPrinter * printer = [[[QPrinter alloc] init] autorelease];
  [[self statusBar] message: @"Printing..."];
  if ([printer setup: self])
  {
    QPainter * painter = [[[QPainter alloc] init] autorelease];
    [painter begin: printer];

    ///////////////////////////////////////////////////////////////////
    // TODO: Define printing by using the QPainter methods here

    [painter end];
  };

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotFileQuit
{
  [[self statusBar] message: @"Exiting application..."];
  ///////////////////////////////////////////////////////////////////
  // exits the Application
  if([doc isModified])
  {
    if([self queryExit])
    {
      [[QApplication qApp] quit];
    }
    else
    {

    };
  }
  else
  {
    [[QApplication qApp] quit];
  };

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotEditCut
{
  [[self statusBar] message: @"Cutting selection..."];

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotEditCopy
{
  [[self statusBar] message: @"Copying selection to clipboard..."];

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotEditPaste
{
  [[self statusBar] message: @"Inserting clipboard contents..."];

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotViewToolBar
{
  [[self statusBar] message: @"Toggle toolbar..."];
  ///////////////////////////////////////////////////////////////////
  // turn Toolbar on or off

  if ([fileToolbar isVisible])
  {
    [fileToolbar hide];
    [viewMenu setItemChecked: ID_VIEW_TOOLBAR check: NO];
  }
  else
  {
    [fileToolbar show];
    [viewMenu setItemChecked: ID_VIEW_TOOLBAR check: YES];
  };

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotViewStatusBar
{
  [[self statusBar] message: @"Toggle statusbar..."];
  ///////////////////////////////////////////////////////////////////
  //turn Statusbar on or off

  if ([[self statusBar]  isVisible])
  {
    [[self statusBar]  hide];
    [viewMenu setItemChecked: ID_VIEW_STATUSBAR check: NO];
  }
  else
  {
    [[self statusBar]  show];
    [viewMenu setItemChecked: ID_VIEW_STATUSBAR check: YES];
  }

  [[self statusBar] message: [NSString stringWithCString: IDS_STATUS_DEFAULT]];
}

- (void) slotHelpAbout
{
  [QMessageBox about: self caption: @"About..."
                     text: [NSString stringWithCString: IDS_APP_ABOUT] ];
}

- (void) slotStatusHelpMsg: (NSString *) text
{
  ///////////////////////////////////////////////////////////////////
  // change status message of whole statusbar temporary (text, msec)
  [[self statusBar] message: text milliSeconds: 2000];
}

- (void) statusCallback: (int) id_
{
  switch (id_)
  {
    case ID_FILE_NEW:
         [self slotStatusHelpMsg: @"Creates a new document"];
         break;

    case ID_FILE_OPEN:
         [self slotStatusHelpMsg: @"Opens an existing document"];
         break;

    case ID_FILE_SAVE:
         [self slotStatusHelpMsg: @"Saves the actual document"];
         break;

    case ID_FILE_SAVE_AS:
         [self slotStatusHelpMsg: @"Saves the actual document as..."];
         break;

    case ID_FILE_CLOSE:
         [self slotStatusHelpMsg: @"Closes the actual document"];
         break;

    case ID_FILE_PRINT:
         [self slotStatusHelpMsg: @"Prints out the actual document"];
         break;

    case ID_FILE_QUIT:
         [self slotStatusHelpMsg: @"Quits the application"];
         break;

    case ID_EDIT_CUT:
         [self slotStatusHelpMsg: @"Cuts the selected section and puts it to the clipboard"];
         break;

    case ID_EDIT_COPY:
         [self slotStatusHelpMsg: @"Copies the selected section to the clipboard"];
         break;

    case ID_EDIT_PASTE:
         [self slotStatusHelpMsg: @"Pastes the clipboard contents to actual position"];
         break;

    case ID_EDIT_SELECT_ALL:
         [self slotStatusHelpMsg: @"Selects the whole document contents"];
         break;

    case ID_VIEW_TOOLBAR:
         [self slotStatusHelpMsg: @"Enables/disables the toolbar"];
         break;

    case ID_VIEW_STATUSBAR:
         [self slotStatusHelpMsg: @"Enables/disables the statusbar"];
         break;

    case ID_HELP_ABOUT:
         [self slotStatusHelpMsg: @"Shows an aboutbox"];
         break;
  }
}

@end

