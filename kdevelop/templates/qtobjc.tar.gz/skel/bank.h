
#ifndef |NAMEBIG|_H
#define |NAMEBIG|_H

#include <Foundation/NSString.h>

// include files for QT
#include <qtobjc/QPopupMenu.h>
#include <qtobjc/QMainWindow.h>
#include <qtobjc/QAccel.h>
#include <qtobjc/QMenuBar.h>
#include <qtobjc/QToolBar.h>
#include <qtobjc/QPixmap.h>
#include <qtobjc/QToolButton.h>
#include <qtobjc/QApplication.h>
#include <qtobjc/QStatusBar.h>
#include <qtobjc/QWhatsThis.h>
#include <qtobjc/QMessageBox.h>
#include <qtobjc/QFileDialog.h>
#include <qtobjc/QPrinter.h>
#include <qtobjc/QPainter.h>

// application specific includes
#include "|NAME|View.h"
#include "|NAME|Doc.h"
#include "resource.h"

/**
  * This Class is the base class for your application. It sets up the main
  * window and providing a menubar, toolbar
  * and statusbar. For the main view, an instance of class |NAME|View is
  * created which creates your view.
  */
@interface |NAME| : QMainWindow
{
  @private

    /** view is the main widget which represents your working area. The View
     * class should handle all events of the view widget.  It is kept empty so
     * you can create your view according to your application's needs by
     * changing the view class.
     */
    |NAME|View *view;
    /** doc represents your actual document and is created only once. It keeps
     * information such as filename and does the serialization of your files.
     */
    |NAME|Doc *doc;

    /** file_menu contains all items of the menubar entry "File" */
    QPopupMenu *fileMenu;
    /** edit_menu contains all items of the menubar entry "Edit" */
    QPopupMenu *editMenu;
    /** view_menu contains all items of the menubar entry "View" */
    QPopupMenu *viewMenu;
    /** view_menu contains all items of the menubar entry "Help" */
    QPopupMenu *helpMenu;

    QToolBar *fileToolbar;
}
    /** construtor */
    - init;
    /** destructor */
    - (void) dealloc;
    /** initMenuBar creates the menu_bar and inserts the menuitems */
    - (void) initMenuBar;
    /** this creates the toolbars. Change the toobar look and add new toolbars in this
     * function */
    - (void) initToolBar;
    /** setup the statusbar */
    - (void) initStatusBar;
    /** setup the document*/
    - (void) initDoc;
    /** setup the mainview*/
    - (void) initView;

    /** overloaded for Message box on last window exit */
    - (BOOL) queryExit;

//  public slots:

    /** switch argument for Statusbar help entries on slot selection */
    - (void) statusCallback: (int) id_;
    /** open a new application window */

    /** generate a new document in the actual view */
    - (void) slotFileNew;
    /** open a document */
    - (void) slotFileOpen;
    /** save a document */
    - (void) slotFileSave;
    /** save a document under a different filename*/
    - (void) slotFileSaveAs;
    /** close the actual file */
    - (void) slotFileClose;
    /** print the actual file */
    - (void) slotFilePrint;
    /** exits the application */
    - (void) slotFileQuit;
    /** put the marked text/object into the clipboard and remove
     * it from the document */
    - (void) slotEditCut;
    /** put the marked text/object into the clipboard*/
    - (void) slotEditCopy;
    /** paste the clipboard into the document*/
    - (void) slotEditPaste;
    /** toggle the toolbar*/
    - (void) slotViewToolBar;
    /** toggle the statusbar*/
    - (void) slotViewStatusBar;

    /** shows an about dlg*/
    - (void) slotHelpAbout;

    /** change the status message of the whole statusbar temporary */
    - (void) slotStatusHelpMsg: (NSString *) text;


@end

#endif 

