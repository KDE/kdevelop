
#include "|NAME|View.h"

@implementation |NAME|View

- initWithParent: (QWidget *) parent doc: (|NAME|Doc*) doc
{
	[super initWithParent: parent];
	
	/** connect doc with the view*/
	[QObject connect: doc signal: @"documentChanged" receiver: self slot: @"slotDocumentChanged"];
	return self;
}

- (void) dealloc
{
	[super dealloc];
	return;
}

- (void) slotDocumentChanged
{
  //TODO update the view

}

@end
