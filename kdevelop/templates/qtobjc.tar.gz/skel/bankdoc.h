#ifndef |NAMEBIG|DOC_H
#define |NAMEBIG|DOC_H

#include <Foundation/NSObject.h>

// include files for QT
#include <qtobjc/QObject.h>

// application specific includes

/**
  * the Document Class
  */

@interface |NAME|Doc : QObject
{
  @protected
    BOOL modified;
}
    - init;
    - (void) dealloc;
    - (void) newDoc;
    - (BOOL) save;
    - (BOOL) saveAs: (NSString *) filename;
    - (BOOL) load: (NSString *) filename;
    - (BOOL) isModified;
@end

#endif
