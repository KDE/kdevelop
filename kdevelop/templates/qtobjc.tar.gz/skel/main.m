
#include <Foundation/NSString.h>

#include <qtobjc/QApplication.h>
#include <qtobjc/QFont.h>

#include "|NAME|.h"

int main(int argc, char *argv[])
{
  |NAME| * |NAMELITTLE|;

  QApplication * a = [[QApplication alloc] initWithArgc: argc argv: argv];
  [QApplication setFont: [[QFont alloc] initWithFamily: @"helvetica" pointSize: 12]];
  /* uncomment the following line, if you want a Windows 95 look*/
  // [QApplication setStyle: WindowsStyle];
	
  |NAMELITTLE| = [[|NAME| alloc] init];
  [a setMainWidget: |NAMELITTLE|];
	
  [|NAMELITTLE| setCaption: @"Document 1"];
  [|NAMELITTLE| show];
	
  return [a exec];
}
