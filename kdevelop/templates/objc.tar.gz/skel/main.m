
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <Foundation/NSString.h>

int main(int argc, char *argv[])
{
  NSLog(@"Hello, world!");
  return EXIT_SUCCESS;
}
