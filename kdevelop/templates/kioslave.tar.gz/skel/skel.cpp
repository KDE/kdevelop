#include <qcstring.h>
#include <qsocket.h>
#include <qdatetime.h>
#include <qbitarray.h>

#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <kapp.h>
#include <kdebug.h>
#include <kmessagebox.h>
#include <kinstance.h>
#include <kglobal.h>
#include <kstddirs.h>
#include <klocale.h>
#include <kurl.h>
#include <ksock.h>

#include "|NAMELITTLE|.h"


using namespace KIO;
extern "C"
{
  int kdemain( int argc, char **argv )
  {
    KInstance instance( "kio_|NAMELITTLE|" );
    
    kdDebug(7101) << "*** Starting kio_|NAMELITTLE| " << endl;
    
    if (argc != 4)
      {
	kdDebug(7101) << "Usage: kio_|NAMELITTLE|  protocol domain-socket1 domain-socket2" << endl;
	exit(-1);
      }
    
    kio_|NAMELITTLE|Protocol slave(argv[2], argv[3]);
    slave.dispatchLoop();
    
    kdDebug(7101) << "*** kio_|NAMELITTLE| Done" << endl;
    return 0;
  }
} 

kio_|NAMELITTLE|Protocol::kio_|NAMELITTLE|Protocol(const QCString &pool_socket, const QCString &app_socket)
  : QObject(), SlaveBase("kio_|NAMELITTLE|", pool_socket, app_socket)
{
 kdDebug() << "kio_|NAMELITTLE|Protocol::kio_|NAMELITTLE|Protocol()" << endl;
}
/* ---------------------------------------------------------------------------------- */


kio_|NAMELITTLE|Protocol::~kio_|NAMELITTLE|Protocol()
{
  kdDebug() << "kio_|NAMELITTLE|Protocol::~kio_|NAMELITTLE|Protocol()" << endl;
  delete myURL;
}


/* ---------------------------------------------------------------------------------- */
void kio_|NAMELITTLE|Protocol::get(const KURL& url )
{
  kdDebug() << "kio_|NAMELITTLE|::get(const KURL& url)" << endl ;

  this->parseCommandLine(url);
  kdDebug() << "Seconds: " << myURL->query() << endl;
  QString remoteServer = myURL->host();
  int remotePort = myURL->port();
  kdDebug() << "myURL: " << myURL->prettyURL() << endl;

  infoMessage("Looking for " + remoteServer + "...");
  QString theData = "This is a test of |NAME|";
  data(QCString(theData.local8Bit()));
  data(QByteArray());
  finished();
}

/* ---------------------------------------------------------------------------------- */


void kio_|NAMELITTLE|Protocol::mimetype(const KURL & /*url*/)
{
  mimeType("text/plain");
  finished();
}


/* --------------------------------------------------------------------------- */


void kio_|NAMELITTLE|Protocol::parseCommandLine(const KURL& url)
{
  myURL = new KURL(url);
  myURL->setUser("");
  /*
   * Generate a valid |NAMELITTLE| url
   */

  if(myURL->isEmpty() ||
     myURL->isMalformed() || 
     (myURL->user().isEmpty() && myURL->host().isEmpty())) 
    {
      myURL->setProtocol("|NAMELITTLE|");
      myURL->setUser("");
      myURL->setHost("localhost");
    }

  /*
   * If no specifc port is specified, set it to 37.
   */

  if(myURL->port() == 0) {
    myURL->setPort(37);
  }
}
#include "|NAMELITTLE|.moc"
