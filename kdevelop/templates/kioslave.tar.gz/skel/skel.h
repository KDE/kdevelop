#ifndef __|NAMELITTLE|_h__
#define __|NAMELITTLE|_h__

#include <qstring.h>
#include <qcstring.h>


#include <kurl.h>
#include <kio/global.h>
#include <kio/slavebase.h>

class QCString;

class kio_|NAMELITTLE|Protocol : public QObject, public KIO::SlaveBase
{
  Q_OBJECT

public:
  kio_|NAMELITTLE|Protocol(const QCString &pool_socket, const QCString &app_socket);
  virtual ~kio_|NAMELITTLE|Protocol();
  virtual void mimetype(const KURL& url);
  virtual void get(const KURL& url);

private:
  KURL       *myURL;
  void       parseCommandLine(const KURL& url);
};


#endif
