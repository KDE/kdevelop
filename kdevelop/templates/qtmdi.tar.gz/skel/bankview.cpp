
// include files for Qt
#include <qprinter.h>
#include <qpainter.h>

// application specific includes
#include "|NAMELITTLE|view.h"
#include "|NAMELITTLE|doc.h"


|NAME|View::|NAME|View(|NAME|Doc* pDoc, QWidget *parent, const char* name, int wflags)
 : QWidget(parent, name, wflags)
{
    doc=pDoc;
}

|NAME|View::~|NAME|View()
{
}

|NAME|Doc *|NAME|View::getDocument() const
{
	return doc;
}

void |NAME|View::update(|NAME|View* pSender){
	if(pSender != this)
		repaint();
}

void |NAME|View::print(QPrinter *pPrinter)
{
  if (pPrinter->setup(this))
  {
		QPainter p;
		p.begin(pPrinter);
		
		///////////////////////////////
		// TODO: add your printing code here
		///////////////////////////////
		
		p.end();
  }
}

void |NAME|View::closeEvent(QCloseEvent*)
{
  // LEAVE THIS EMPTY: THE EVENT FILTER IN THE |NAME|App CLASS TAKES CARE FOR CLOSING
  // QWidget closeEvent must be prevented.
}