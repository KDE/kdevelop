
#include <qapplication.h>
#include <qfont.h>

#include "|NAMELITTLE|.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  a.setFont(QFont("helvetica", 12));

  |NAME|App *|NAMELITTLE|=new |NAME|App();
  a.setMainWidget(|NAMELITTLE|);

  |NAMELITTLE|->show();

  if(argc>1)
    |NAMELITTLE|->openDocumentFile(argv[1]);
	else
	  |NAMELITTLE|->openDocumentFile();
	
  return a.exec();
}
