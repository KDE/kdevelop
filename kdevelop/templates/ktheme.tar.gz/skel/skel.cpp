#ifndef INCLUDE_MENUITEM_DEF
#define INCLUDE_MENUITEM_DEF
#endif

#include <qmenudata.h>
#include <qpalette.h>
#include <qbitmap.h>
#include <qtabbar.h>
#include <qpointarray.h>

#include <kapp.h>
#include <kdrawutil.h>
#include <klocale.h>

#include "|NAMELITTLE|.h"

extern "C"
{
  KStyle *      allocate()      { return new |NAME|; }
  int           minor_version() { return 0; }
  int           major_version() { return 1; }
  const char *  description()   { return(i18n("A funky syle").utf8()); }
}

|NAME|::|NAME|()
	: KStyle()
{
}

|NAME|::~|NAME|()
{
	// Empty.
}

	void
|NAME|::polish(QApplication * app)
{
	KStyle::polish(app);
}

	void
|NAME|::polish(QPalette & pal)
{
	KStyle::polish(pal);
}

	void
|NAME|::unPolish(QApplication * app)
{
	KStyle::unPolish(app);
}

	void
|NAME|::polish(QWidget * w)
{
	KStyle::polish(w);
}

	void
|NAME|::unPolish(QWidget * w)
{
	KStyle::unPolish(w);
}

	void
|NAME|::drawButton
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 const QBrush * fill
)
{
	KStyle::drawButton(p, x, y, w, h, g, sunken, fill);
}

	QRect
|NAME|::buttonRect(int x, int y, int w, int h)
{
	return KStyle::buttonRect(x, y, w, h);
}

	void
|NAME|::drawBevelButton
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 const QBrush * fill
)
{
	KStyle::drawBevelButton(p, x, y, w, h, g, sunken, fill);
}

	void
|NAME|::drawPushButton(QPushButton * b, QPainter * p)
{
	KStyle::drawPushButton(b, p);
}

	void
|NAME|::drawPushButtonLabel(QPushButton * b, QPainter * p)
{
	KStyle::drawPushButtonLabel(b, p);
}

	void
|NAME|::drawScrollBarControls
(
 QPainter * p,
 const QScrollBar * sb,
 int sliderStart,
 uint controls,
 uint activeControl
)
{
	KStyle::drawScrollBarControls(p, sb, sliderStart, controls, activeControl);
}

	QStyle::ScrollControl
|NAME|::scrollBarPointOver
(
 const QScrollBar * sb,
 int sliderStart,
 const QPoint & point
)
{
	return KStyle::scrollBarPointOver(sb, sliderStart, point);
}

	void
|NAME|::scrollBarMetrics
(
 const QScrollBar * sb,
 int & sliderMin,
 int & sliderMax,
 int & sliderLength,
 int & buttonDim
)
{
	KStyle::scrollBarMetrics(sb, sliderMin, sliderMax, sliderLength, buttonDim);
}

	QSize
|NAME|::indicatorSize() const
{
	return KStyle::indicatorSize();
}

	void
|NAME|::drawIndicator
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 int state,
 bool down,
 bool enabled
)
{
	KStyle::drawIndicator(p, x, y, w, h, g, state, down, enabled);
}

	QSize
|NAME|::exclusiveIndicatorSize() const
{
	return KStyle::exclusiveIndicatorSize();
}

	void
|NAME|::drawExclusiveIndicator
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool on,
 bool down,
 bool enabled
)
{
	KStyle::drawExclusiveIndicator(p, x, y, w, h, g, on, down, enabled);
}

	void
|NAME|::drawIndicatorMask
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 int state
)
{
	KStyle::drawIndicatorMask(p, x, y, w, h, state);
}

	void
|NAME|::drawExclusiveIndicatorMask
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 bool on
)
{
	KStyle::drawExclusiveIndicatorMask(p, x, y, w, h, on);
}

	void
|NAME|::drawComboButton
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 bool editable,
 bool enabled,
 const QBrush * fill
)
{
	KStyle::drawComboButton(p, x, y, w, h, g, sunken, editable, enabled, fill);
}

	QRect
|NAME|::comboButtonRect(int x, int y, int w, int h)
{
	return KStyle::comboButtonRect(x, y, w, h);
}

	QRect
|NAME|::comboButtonFocusRect(int x, int y, int w, int h)
{
	return KStyle::comboButtonFocusRect(x, y, w, h);
}

	int
|NAME|::sliderLength() const
{
	return KStyle::sliderLength();
}

	void
|NAME|::drawSliderGroove
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 QCOORD c,
 Orientation o
)
{
	KStyle::drawSliderGroove(p, x, y, w, h, g, c, o);
}

	void
|NAME|::drawArrow
(
 QPainter * p,
 Qt::ArrowType type,
 bool down,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool enabled,
 const QBrush * fill
)
{
	KStyle::drawArrow(p, type, down, x, y, w, h, g, enabled, fill);
}

	void
|NAME|::drawSlider
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 Orientation o,
 bool tickAbove,
 bool tickBelow
)
{
	KStyle::drawSlider(p, x, y, w, h, g, o, tickAbove, tickBelow);
}

	void
|NAME|::drawKToolBar
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 KToolBarPos pos,
 QBrush * fill
)
{
	KStyle::drawKToolBar(p, x, y, w, h, g, pos, fill);
}

	void
|NAME|::drawKBarHandle
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 KToolBarPos pos,
 QBrush * fill
)
{
	KStyle::drawKBarHandle(p, x, y, w, h, g, pos, fill);
}

	void
|NAME|::drawKMenuBar
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool macMode,
 QBrush * fill
)
{
	KStyle::drawKMenuBar(p, x, y, w, h, g, macMode, fill);
}

	void
|NAME|::drawKToolBarButton
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 bool raised,
 bool enabled,
 bool popup,
 KToolButtonType type,
 const QString & btext,
 const QPixmap * pixmap,
 QFont * font,
 QWidget * button
)
{
	KStyle::drawKToolBarButton
		(
		 p,
		 x,
		 y,
		 w,
		 h,
		 g,
		 sunken,
		 raised,
		 enabled,
		 popup,
		 type,
		 btext,
		 pixmap,
		 font,
		 button
		);
}

	void
|NAME|::drawKMenuItem
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool active,
 QMenuItem * mi,
 QBrush * fill
)
{
	KStyle::drawKMenuItem(p, x, y, w, h, g, active, mi, fill);
}

	void
|NAME|::drawPopupMenuItem
(
 QPainter * p,
 bool checkable,
 int maxpmw,
 int tab,
 QMenuItem * mi,
 const QPalette & pal,
 bool act,
 bool enabled,
 int x,
 int y,
 int w,
 int h
)
{
	KStyle::drawPopupMenuItem(p, checkable, maxpmw, tab, mi, pal, act, enabled, x, y, w, h);
}

	void
|NAME|::drawKProgressBlock
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 QBrush * fill
)
{
	KStyle::drawKProgressBlock(p, x, y, w, h, g, fill);
}

	void
|NAME|::drawFocusRect
(
 QPainter * p,
 const QRect & r,
 const QColorGroup & g,
 const QColor * pen,
 bool atBorder
)
{
	KStyle::drawFocusRect(p, r, g, pen, atBorder);
}

  void
|NAME|::drawPanel
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 int lineWidth,
 const QBrush * brush
)
{
  KStyle::drawPanel(p, x, y, w, h, g, sunken, lineWidth, brush);
}

  void
|NAME|::drawPopupPanel
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 int lineWidth,
 const QBrush * brush
)
{
  KStyle::drawPopupPanel(p, x, y, w, h, g, lineWidth, brush);
}

  void
|NAME|::drawSeparator
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 bool sunken,
 int lineWidth,
 int midLineWidth 
)
{
  KStyle::drawSeparator(p, x, y, w, h, g, sunken, lineWidth, midLineWidth);
}

  void
|NAME|::drawTab
(
 QPainter * p,
 const QTabBar * tabBar,
 QTab * tab,
 bool selected
)
{
  KStyle::drawTab(p, tabBar, tab, selected);
}

  void
|NAME|::drawTabMask
(
 QPainter * p,
 const QTabBar * tabBar,
 QTab * tab,
 bool selected
)
{
  KStyle::drawTabMask(p, tabBar, tab, selected);
}

  void
|NAME|::drawKickerHandle
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 QBrush * brush
)
{
  KStyle::drawKickerHandle(p, x, y, w, h, g, brush);
}

  void
|NAME|::drawKickerAppletHandle
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 QBrush * brush
)
{
  KStyle::drawKickerAppletHandle(p, x, y, w, h, g, brush);
}

  void
|NAME|::drawKickerTaskButton
(
 QPainter * p,
 int x,
 int y,
 int w,
 int h,
 const QColorGroup & g,
 const QString & title,
 bool active,
 QPixmap * icon,
 QBrush * brush
)
{
  KStyle::drawKickerTaskButton(p, x, y, w, h, g, title, active, icon, brush);
}

  bool
|NAME|::eventFilter(QObject *, QEvent *)
{
  return false;
}


