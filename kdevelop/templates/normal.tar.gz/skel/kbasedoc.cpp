
#include <qdir.h>
#include <qfileinfo.h>

#include <kapp.h>
#include <kmsgbox.h>

#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|view.h"


|NAME|Doc::|NAME|Doc(QObject *parent, const char* name):QObject(parent, name)
{
}

|NAME|Doc::~|NAME|Doc()
{
}

void |NAME|Doc::addView(|NAME|View* m_pView)
{
	m_view=m_pView;
}

const QString& |NAME|Doc::getPathName() const
{
	return m_path;
}

void |NAME|Doc::pathName( const char* path_name)
{
	m_path=path_name;
}
void |NAME|Doc::title( const char* title)
{
	m_title=title;
}

const QString& |NAME|Doc::getTitle() const
{
	return m_title;
}


void |NAME|Doc::closeDocument()
{
	deleteContents();
}

bool |NAME|Doc::newDocument()
{
	
	/////////////////////////////////////////////////
	// TODO: Add your document initialization code here
	/////////////////////////////////////////////////
	b_modified=false;
	return true;
}

bool |NAME|Doc::openDocument(const char* filename, const char* format)
{
	QFileInfo fileInfo(filename);
	m_title=fileInfo.fileName();
	m_path=fileInfo.absFilePath();	
	/////////////////////////////////////////////////
	// TODO: Add your document opening code here
	/////////////////////////////////////////////////
	
	b_modified=false;
	return true;
}

bool |NAME|Doc::saveDocument(const char* filename, const char* format)
{

	/////////////////////////////////////////////////
	// TODO: Add your document saving code here
	/////////////////////////////////////////////////

	b_modified=false;
	return true;
}

void |NAME|Doc::deleteContents()
{
	/////////////////////////////////////////////////
	// TODO: Add implementation to delete the document contents
	/////////////////////////////////////////////////

}




