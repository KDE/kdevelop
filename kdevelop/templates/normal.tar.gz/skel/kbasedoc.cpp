
#include <kbasedoc.h>

KBaseDoc::KBaseDoc(QObject *parent, const char *filename):QObject(parent){
}

KBaseDoc::~KBaseDoc(){
}
