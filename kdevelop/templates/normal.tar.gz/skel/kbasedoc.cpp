
#include <qdir.h>
#include <qfileinfo.h>

#include <kapp.h>
#include <kmsgbox.h>

#include <kbasedoc.h>
#include "kbaseview.h"


KBaseDoc::KBaseDoc(QObject *parent, const char* name):QObject(parent, name)
{
}

KBaseDoc::~KBaseDoc()
{
}

void KBaseDoc::addView(KBaseView* m_pView)
{
	m_view=m_pView;
}

const QString& KBaseDoc::getPathName() const
{
	return m_path;
}

void KBaseDoc::pathName( const char* path_name)
{
	m_path=path_name;
}
void KBaseDoc::title( const char* title)
{
	m_title=title;
}

const QString& KBaseDoc::getTitle() const
{
	return m_title;
}


void KBaseDoc::closeDocument()
{
	deleteContents();
}

bool KBaseDoc::newDocument()
{
	
	/////////////////////////////////////////////////
	// TODO: Add your document initialization code here
	/////////////////////////////////////////////////
	b_modified=false;
	return true;
}

bool KBaseDoc::openDocument(const char* filename, const char* format)
{
	QFileInfo fileInfo(filename);
	m_title=fileInfo.fileName();
	m_path=fileInfo.absFilePath();	
	/////////////////////////////////////////////////
	// TODO: Add your document opening code here
	/////////////////////////////////////////////////
	
	b_modified=false;
	return true;
}

bool KBaseDoc::saveDocument(const char* filename, const char* format)
{

	/////////////////////////////////////////////////
	// TODO: Add your document saving code here
	/////////////////////////////////////////////////

	b_modified=false;
	return true;
}

void KBaseDoc::deleteContents()
{
	/////////////////////////////////////////////////
	// TODO: Add implementation to delete the document contents
	/////////////////////////////////////////////////

}




