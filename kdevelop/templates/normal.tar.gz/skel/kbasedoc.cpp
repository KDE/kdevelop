
// include files for Qt
#include <qdir.h>
#include <qfileinfo.h>
#include <qwidget.h>

// include files for KDE
#include <kapp.h>
#include <kmsgbox.h>

// application specific includes
#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|.h"
#include "|NAMELITTLE|view.h"

QList<|NAME|View> *|NAME|Doc::pViewList = 0L;

|NAME|Doc::|NAME|Doc(QWidget *parent, const char *name) : QObject(parent, name)
{
  if(!pViewList)
  {
    pViewList = new QList<|NAME|View>();
  }
}

|NAME|Doc::~|NAME|Doc()
{
}

void |NAME|Doc::addView(|NAME|View *view)
{
  pViewList->append(view);
}

void |NAME|Doc::removeView(|NAME|View *view)
{
  pViewList->remove(view);
}

void |NAME|Doc::setAbsFilePath(const QString &filename)
{
  absFilePath=filename;
}

const QString &|NAME|Doc::getAbsFilePath() const
{
  return absFilePath;
}

void |NAME|Doc::setTitle(const QString &_t)
{
  title=_t;
}

const QString &|NAME|Doc::getTitle() const
{
  return title;
}

void |NAME|Doc::slotUpdateAllViews(|NAME|View *sender)
{
  |NAME|View *w;
  if(pViewList)
  {
    for(w=pViewList->first(); w!=0; w=pViewList->next())
    {
      if(w!=sender)
        w->repaint();
    }
  }

}

bool |NAME|Doc::saveModified()
{
  bool completed=true;

  if(modified)
  {
    |NAME|App *win=(|NAME|App *) parent();
    int want_save = KMsgBox::yesNoCancel(win, i18n("Warning"),
                                         i18n("The current file has been modified.\n"
                                              "Do you want to save it?"));
    switch(want_save)
    {
      case 1:
           if (title == i18n("Untitled"))
           {
             win->slotFileSaveAs();
           }
           else
           {
             saveDocument(getAbsFilePath());
       	   };

       	   deleteContents();
           completed=true;
           break;

      case 2:
           setModified(false);
           deleteContents();
           completed=true;
           break;	

      case 3:
           completed=false;
           break;

      default:
           completed=false;
           break;
    }
  }

  return completed;
}

void |NAME|Doc::closeDocument()
{
  deleteContents();
}

bool |NAME|Doc::newDocument()
{
  /////////////////////////////////////////////////
  // TODO: Add your document initialization code here
  /////////////////////////////////////////////////
  modified=false;
  absFilePath=QDir::homeDirPath();
  title=i18n("Untitled");

  return true;
}

bool |NAME|Doc::openDocument(const QString &filename, const char *format /*=0*/)
{
  QFileInfo fileInfo(filename);
  title=fileInfo.fileName();
  absFilePath=fileInfo.absFilePath();	
  /////////////////////////////////////////////////
  // TODO: Add your document opening code here
  /////////////////////////////////////////////////
	
  modified=false;
  return true;
}

bool |NAME|Doc::saveDocument(const QString &filename, const char *format /*=0*/)
{
  /////////////////////////////////////////////////
  // TODO: Add your document saving code here
  /////////////////////////////////////////////////

  modified=false;
  return true;
}

void |NAME|Doc::deleteContents()
{
  /////////////////////////////////////////////////
  // TODO: Add implementation to delete the document contents
  /////////////////////////////////////////////////

}
