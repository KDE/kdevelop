#include <kbasedoc.h>

KBaseDoc::KBaseDoc(QObject *parent, const char *filename):QObject(parent)
{
  bModified = false;
}

KBaseDoc::~KBaseDoc()
{
}

void KBaseDoc::deleteContents()
{
 setModified(false);

}

void KBaseDoc::saveFile()
{
 QString name =  KFileDialog::getSaveFileName(); 
 setModified(false);
}

void KBaseDoc::openFile()
{
  KFileDialog::getOpenFileName();
  setModified(false);
}

void KBaseDoc::setModified(bool m)
{
  bModified = m;
}
