
#ifndef |NAMEBIG|_H
#define |NAMEBIG|_H 
 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


// include files for KDE 
#include <kapp.h>
#include <ktmainwindow.h>
#include <kaccel.h>

class |NAME|Doc;
class |NAME|View;
/**
  * This Class is the base class for your application. It sets up the main
  * window and reads the config file as well as providing a menubar, toolbar
  * and statusbar. For the main view, an instance of class KBaseView is
  * created which creates your view.
  */
class |NAME|App : public KTMainWindow 
{
  Q_OBJECT

  friend class |NAME|View;

public:
  /** construtor of KBaseApp, calls all init functions to create the application.*/
  |NAME|App(); 

  ~|NAME|App();
  /** enable menuentries/toolbar items */
  void enableCommand(int id_);
  /** disable menuentries/toolbar items */
  void disableCommand(int id_);
	/** add a opened file to the recent file list and update recent_file_menu */
	void addRecentFile(const char* file);
	/** opens a file specified by commandline option */
	void openFile(const char* _cmdl);
	/** asks the user to save the file if modified */
	bool saveModified();
	
	|NAME|Doc* getDocument() const; 	
protected:
 	/** save general Options like all bar positions and status as well as the geometry and the recent file list to the configuration
		* file*/ 	
	void saveOptions();
	/** read general Options again and initialize all variables like the recent file list*/
	void readOptions();
	/** initKeyAccel creates the keyboard accelerator items */
	void initKeyAccel();
  /** initMenuBar creates the menu_bar and inserts the menuitems */
  void initMenuBar();
  /** this creates the toolbars. Change the toobar look and add new toolbars in this
    * function */
  void initToolBar();
  /** setup the statusbar */
  void initStatusBar();
	/** initializes the document */
	void initDocument();
  /** creates the centerwidget of the KTMainWindow instance and sets it as the view*/
  void initView();

  /** save the app-specific options on slotAppExit or by an Options dialog */
  virtual void saveProperties(KConfig* );
  /** read the app-specific options on init() or by an Options dialog */
  virtual void readProperties(KConfig* );
	/** the close event when the main windows are closed */
	virtual void closeEvent ( QCloseEvent *);

 public slots:
  /** switch argument for slot selection by menu or toolbar ID */
  void commandCallback(int id_);
  /** switch argument for Statusbar help entries on slot selection. Add your ID's help here for toolbars and menubar entries. */
  void statusCallback(int id_);
  /** open a new application window by creating a new instance of KBaseApp */
  void slotFileNewWindow();
  /** clears the document in the actual view to reuse it as the new document */
  void slotFileNew();
  /** open a file and load it into the document*/
  void slotFileOpen();
	/** opens a file from the recent files menu */
	void slotFileOpenRecent(int id_);
  /** save a document */
  void slotFileSave();
  /** save a document by a new filename*/
  void slotFileSaveAs();
  /** asks for saving if the file is modified, then closes the actual file and window*/
  void slotFileClose();
  /** print the actual file */
  void slotFilePrint();
  /** closes all open windows by calling slotFileClose and exits the application*/
  void slotFileQuit();
  /** put the marked text/object into the clipboard and remove
    *	it from the document */
  void slotEditCut();
  /** put the marked text/object into the clipboard*/
  void slotEditCopy();
  /** paste the clipboard into the document*/
  void slotEditPaste();
  /** toggles the toolbar*/
  void slotViewToolBar();
  /** toggles the statusbar*/
  void slotViewStatusBar();
  /** changes the status message to text */
  void slotStatusMsg(const char *text);
  /** changes the status message of the whole statusbar temporary */
  void slotStatusHelpMsg(const char *text);

protected:
	/** the list of open windows */
	static QList<|NAME|App> windowList;

private:
	/** the configuration object of the application */
	KConfig* config;
	/** the key accelerator container */
	KAccel* key_accel;
  /** file_menu contains all items of the menubar entry "File" */
  QPopupMenu *file_menu;
	/** the recent file menu containing the last five opened files */
	QPopupMenu *recent_files_menu;
	/** contains the recently used filenames */
	QStrList recent_files;
  /** edit_menu contains all items of the menubar entry "Edit" */
  QPopupMenu *edit_menu;
  /** view_menu contains all items of the menubar entry "View" */
  QPopupMenu *view_menu;
  /** help_menu contains all items of the menubar entry "Help" */
  QPopupMenu *help_menu;
  /** view is the main widget which represents your working area. The View
    * class should handle all events of the view widget.  It is kept empty so
    * you can create your view according to your application's needs by
    * changing the view class. */
  |NAME|View *view;
  /** doc represents your actual document and is created only once. It keeps
    * information such as filename and does the serialization of your files.
    */
  |NAME|Doc *doc;
	

};
 
#endif // |NAMEBIG|_H





















