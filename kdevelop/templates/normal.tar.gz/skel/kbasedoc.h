
#ifndef KBASEDOC_H
#define KBASEDOC_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <qobject.h>
#include <qstring.h>
#include <qfileinfo.h>
#include <qlist.h>

class KBaseView;
/**
  * This class provides base functionality for your application document
  */
class KBaseDoc : public QObject
{
  Q_OBJECT

 public:
  /** Constructor for the fileclass of the application */
  KBaseDoc(QObject* parent=0, const char *name=0);
  /** Destructor for the fileclass of the application */
  ~KBaseDoc();
	/** adds a view to the document which represents the document contents. Usually this is your main view. */
  void addView(KBaseView* view);
  /** sets the modified flag for the document after a modifying action on the view connected to the document.*/
  void setModified(bool modified=true){ b_modified=modified; }
	/** returns if the document is modified or not. Use this to determine if your document needs saving by the user on closing.*/
  bool isModified(){ return b_modified;}
	/** deletes the document's contents */
	void deleteContents();
	/** initializes the document generally */
	bool newDocument();
	/** closes the acutal document */
	void closeDocument();
	/** loads the document by filename and format and emits the updateViews() signal */
  bool openDocument(const char* filename, const char* format=0);
  /** saves the document under filename and format.*/	
  bool saveDocument(const char* filename, const char* format=0);
	/** sets the path to the file connected with the document */
	void pathName(const char* path_name);
	/** returns the pathname of the current document file*/
	const QString& getPathName() const;
	/** sets the filename of the document */
	void title(const char* title);
	/** returns the title of the document */
	const QString& getTitle() const;
	
 signals:
	/** the signal updateViews() is emitted on loadDocument to signal the view connected to repaint themselves.
		* Connect updateViews() with repaint() or update() of your QWidget to get a paint event.
		*/
	void updateViews();

 protected:
 	/** the list of the views currently connected to the document */
	KBaseView* m_view;	
 private:
 	/** the modified flag of the current document */
 	bool b_modified;
	QString m_title;
	QString m_path;

};

#endif // KBASEDOC_H











