#ifndef KBASEDOC_H 
#define KBASEDOC_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <qobject.h>
#include <qfile.h>
#include <kfiledialog.h>
/** 
  * This class provides base functionality for your application document
  * such as file creation, saving and closing by serialization of a QFile
  * Object.
  */
class KBaseDoc : public QObject
{
  Q_OBJECT

 public:
  /** Constructor for the fileclass of the application */
  KBaseDoc(QObject*, const char *filename=0L);
  /** Destructor for the fileclass of the application */
  ~KBaseDoc();
  /** returns the value of the modified flag*/
  bool isModified() {return bModified;};
  /** deletes the current document contents */
  void deleteContents();
  /** saves the document to a file. If a file already exists and is created, it
    * saves directly to the file; otherwise it asks for a filename. */
  void saveFile();
  /** opens the file after a file is selected */
  void openFile();

  public slots:
    /** sets the modified flag */
    void setModified(bool m= true);

 private:
  /** modified flag: true, if actual view is modified */
  bool bModified;


};

#endif // KBASEDOC_H


