
#ifndef KBASEDOC_H
#define KBASEDOC_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <qobject.h>
/**
  * This class provides base functionality for your application document
  */
class KBaseDoc : public QObject
{
  Q_OBJECT

 public:
  /** Constructor for the fileclass of the application */
  KBaseDoc(QObject*, const char *filename=0L);
  /** Destructor for the fileclass of the application */
  ~KBaseDoc();

 private:


};

#endif // KBASEDOC_H










