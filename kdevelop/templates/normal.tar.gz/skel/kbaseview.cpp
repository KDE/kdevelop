#include <qprinter.h>
#include <qpainter.h>

#include "|NAMELITTLE|view.h"
#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|.h"

|NAME|View::|NAME|View(QWidget *parent, const char* name) : QWidget(parent, name){
	setBackgroundMode( PaletteBase );

}

|NAME|View::~|NAME|View(){
}


|NAME|Doc* |NAME|View::getDocument() const
{
	|NAME|App* theApp=(|NAME|App*)parentWidget();
	return theApp->getDocument();
}

void |NAME|View::print(QPrinter* m_pPrinter)
{
	QPainter printpainter;
	printpainter.begin(m_pPrinter);
	
	// TODO: add your printing code here
	
	printpainter.end();

}





