#include <kbaseview.h>


KBaseView::KBaseView(QWidget *parent, const char *name)
	: QWidget(parent, name)
{
  ///////////////////////////////////////////////
  //TODO:  setup your Elements for the main view here
  // 
  // [your_main_widget] = new [Main_Widget];
}

KBaseView::~KBaseView()
{
}


void KBaseView::resizeEvent(QResizeEvent *evt)
{
    QWidget::resizeEvent(evt);

    // QRect r = this->geometry();
    // [your_main_widget]->resize(r.width(),r.height());

}

void KBaseView::slotEditCut()
{
}

void KBaseView::slotEditCopy()
{
}

void KBaseView::slotEditPaste()
{
}

