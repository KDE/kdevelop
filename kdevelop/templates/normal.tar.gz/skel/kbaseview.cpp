#include <qprinter.h>
#include <qpainter.h>

#include <kbaseview.h>
#include "kbasedoc.h"
#include "kbase.h"

KBaseView::KBaseView(QWidget *parent, const char* name) : QWidget(parent, name){
	setBackgroundMode( PaletteBase );

}

KBaseView::~KBaseView(){
}


KBaseDoc* KBaseView::getDocument() const
{
	KBaseApp* theApp=(KBaseApp*)parentWidget();
	return theApp->getDocument();
}

void KBaseView::print(QPrinter* m_pPrinter)
{
	QPainter printpainter;
	printpainter.begin(m_pPrinter);
	
	// TODO: add your printing code here
	
	printpainter.end();

}





