
#include <kbaseview.h>


KBaseView::KBaseView(KApplication* a,KBaseDoc* doc,QWidget *parent)
	: QWidget(parent){
}

KBaseView::~KBaseView(){
}


















