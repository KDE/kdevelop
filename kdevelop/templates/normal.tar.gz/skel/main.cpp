
#include "kbase.h" 
 
int main(int argc, char* argv[]) { 
  KApplication app(argc,argv,"kbase");  
 
  if (app.isRestored())
    { 
      RESTORE(KBaseApp);
    }
  else 
    {
      KBaseApp* kbase = new KBaseApp;
      kbase->show();
    }  
  return app.exec();
}  
 
