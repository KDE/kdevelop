
#include "kbase.h" 
 
int main(int argc, char* argv[]) { 
  KApplication app(argc,argv,"KBase");
 
  if (app.isRestored())
    { 
      RESTORE(KBaseApp);
    }
  else 
    {
      KBaseApp* kbase = new KBaseApp;
      kbase->show();
      if(argc > 1){
      	kbase->openFile(argv[1]);
			}
    }
  return app.exec();
}  
 







