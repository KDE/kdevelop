
#ifndef KBASEVIEW_H 
#define KBASEVIEW_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <qwidget.h>

class KBaseDoc;
/**
  * This class provides an incomplete base for your application view. 
   */
class KBaseView : public QWidget
{
  Q_OBJECT

public:
  /** Constructor for the main view */
  KBaseView(QWidget* parent = 0, const char* name=0);
  /** Destructor for the main view */
  ~KBaseView();

	/** gets a pointer to the document connected to the view instance. Then you can call the document members to manipulate it. */
  KBaseDoc* getDocument() const;
	
  /** contains the implementation for printing functionality */
	void print(QPrinter* m_pPrinter);
	
private:
	
};

#endif // KBASEVIEW_H 










