
#ifndef KBASEVIEW_H 
#define KBASEVIEW_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <kapp.h>
#include <qwidget.h>
#include "kbasedoc.h"
/**
  * This class provides an incomplete base for your application view. 
   */

class KBaseView : public QWidget
{
  Q_OBJECT

 public:
  /** Constructor for the main view */
  KBaseView(KApplication* a=0,KBaseDoc* doc=0,QWidget *parent = 0);
  /** Destructor for the main view */
  ~KBaseView();

 private:

};

#endif // KBASEVIEW_H 
