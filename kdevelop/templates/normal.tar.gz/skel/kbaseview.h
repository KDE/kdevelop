
#ifndef |NAMEBIG|VIEW_H 
#define |NAMEBIG|VIEW_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <qwidget.h>

class |NAME|Doc;
/**
  * This class provides an incomplete base for your application view. 
   */
class |NAME|View : public QWidget
{
  Q_OBJECT

public:
  /** Constructor for the main view */
  |NAME|View(QWidget* parent = 0, const char* name=0);
  /** Destructor for the main view */
  ~|NAME|View();

	/** gets a pointer to the document connected to the view instance. Then you can call the document members to manipulate it. */
  |NAME|Doc* getDocument() const;
	
  /** contains the implementation for printing functionality */
	void print(QPrinter* m_pPrinter);
	
private:
	
};

#endif // |NAMEBIG|VIEW_H 










