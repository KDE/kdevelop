#ifndef KBASEVIEW_H 
#define KBASEVIEW_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <kapp.h>
#include <qwidget.h>

/**
  * This class provides an incomplete base for your application view. 
  * This also requires a new implementation of resizeEvent so your view is
  * displayed correctly.  Your View Widget should provide methods to handle
  * the users actions on the view and interact with the doc class of the
  * application to set the modified flag for the document. 
  * Example:  You decided to use a QMultilineEdit widget in your view. This
  * Widget emits a signal textChaged() if the user changes the text. Then, you
  * could use this signal to connect to the slot of the doc class to set the
  * modified flag (which then enables the save and save as items.   */ 

class KBaseView : public QWidget
{
  Q_OBJECT

 public:
  /** Constructor for the main view */
  KBaseView(QWidget *parent = 0, const char *name = 0);
  /** Destructor for the main view */
  virtual ~KBaseView();

  public slots:
    /** put the marked text/object into the clipboard and remove 
     *	it from the document */
    void slotEditCut(); 
    /** put the marked text/object into the clipboard*/
    void slotEditCopy(); 
    /** paste the clipboard into the document*/
    void slotEditPaste();  

 protected:
  /** resizeEvent for the main view */
  virtual void resizeEvent(QResizeEvent *evt);


 private:

  ////////////////////////////////////////////////////////
  // TODO: Add your individual application widgets here

};

#endif // KBASEVIEW_H 
