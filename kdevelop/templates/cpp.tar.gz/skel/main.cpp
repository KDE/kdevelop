#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream.h>
#include <stdlib.h>

int main(int argc, char** argv){
cout << "Hello, World!" << endl;
return EXIT_SUCCESS;
}
