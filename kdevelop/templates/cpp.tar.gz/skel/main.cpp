#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream.h>

int main(){
cout << "Hello World";	
}
