
#ifndef |NAMEBIG|_H
#define |NAMEBIG|_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <kapp.h>
#include <qwidget.h>

/** |NAME| is the base class of the project */
class |NAME| : public QWidget
{
  Q_OBJECT 
  public:
    /** construtor */
    |NAME|(QWidget* parent=0, const char *name=0);
    /** destructor */
    ~|NAME|();
};

#endif
