
#include <kcmdlineargs.h>
#include <kaboutdata.h>
#include <klocale.h>

#include "|NAMELITTLE|.h"

static const char *description =
	I18N_NOOP("|NAME|");
// INSERT A DESCRIPTION FOR YOUR APPLICATION HERE
	
	
static KCmdLineOptions options[] =
{
  { 0, 0, 0 }
  // INSERT YOUR COMMANDLINE OPTIONS HERE
};

int main(int argc, char *argv[])
{

  KAboutData aboutData( "|NAMELITTLE|", I18N_NOOP("|NAME|"),
    VERSION, description, KAboutData::License_GPL,
    "(c) |YEAR|, |AUTHOR|", 0, 0, "|EMAIL|");
  aboutData.addAuthor("|AUTHOR|",0, "|EMAIL|");
  KCmdLineArgs::init( argc, argv, &aboutData );
  KCmdLineArgs::addCmdLineOptions( options ); // Add our own options.

  KApplication a;
  |NAME| *|NAMELITTLE| = new |NAME|();
  a.setMainWidget(|NAMELITTLE|);
  |NAMELITTLE|->show();  

  return a.exec();
}
