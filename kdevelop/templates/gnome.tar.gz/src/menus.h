
/*** gnomehello-menush */

#ifndef GNOMEHELLO_MENUS_H
#define GNOMEHELLO_MENUS_H

#include <gnome.h>

void hello_install_menus_and_toolbar(GtkWidget* app);
      
#endif

/* gnomehello-menush ***/

