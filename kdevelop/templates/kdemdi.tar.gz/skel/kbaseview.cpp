
// include files for Qt
#include <qprinter.h>
#include <qpainter.h>
#include <qdir.h>
// include files for KDE

// application specific includes
#include "|NAMELITTLE|.h"
#include "|NAMELITTLE|view.h"
#include "|NAMELITTLE|view.moc"
#include "|NAMELITTLE|doc.h"

|NAME|View::|NAME|View(|NAME|Doc* pDoc, QWidget *parent, const char* name, int wflags)
 : QWidget(parent, name, wflags)
{
    doc=pDoc;
}

|NAME|View::~|NAME|View()
{
}

|NAME|Doc *|NAME|View::getDocument() const
{
	return doc;
}

void |NAME|View::update(|NAME|View* pSender){
	if(pSender != this)
		repaint();
}

void |NAME|View::print(QPrinter *pPrinter)
{
  if (pPrinter->setup(this))
  {
		QPainter p;
		p.begin(pPrinter);

		///////////////////////////////
		// TODO: add your printing code here
		///////////////////////////////

		p.end();
  }
}

void |NAME|View::closeEvent(QCloseEvent* e){

// DO NOT CALL QWidget::closeEvent(e) here !!
// This will accept the closing by QCloseEvent::accept() by default.
// The installed eventFilter() in |NAME|App takes care for closing the widget
// or ignoring the close event

}
