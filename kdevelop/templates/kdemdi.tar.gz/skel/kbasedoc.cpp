
// include files for Qt
#include <qdir.h>
#include <qfileinfo.h>
#include <qwidget.h>

// include files for KDE
#include <klocale.h>
#include <kmessagebox.h>

// application specific includes
#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|.h"
#include "|NAMELITTLE|view.h"


|NAME|Doc::|NAME|Doc()
{
  pViewList = new QList<|NAME|View>;
  pViewList->setAutoDelete(true);
}

|NAME|Doc::~|NAME|Doc()
{
  delete pViewList;
}

void |NAME|Doc::addView(|NAME|View *view)
{
  pViewList->append(view);
	changedViewList();
}

void |NAME|Doc::removeView(|NAME|View *view)
{
	  pViewList->remove(view);
	  if(!pViewList->isEmpty())
			changedViewList();
		else
			deleteContents();
}

void |NAME|Doc::changedViewList(){	
	
	|NAME|View *w;
	if((int)pViewList->count() == 1){
  	w=pViewList->first();
  	w->setCaption(m_title);
	}
	else{	
		int i;
    for( i=1,w=pViewList->first(); w!=0; i++, w=pViewList->next())
  		w->setCaption(QString(m_title+":%1").arg(i));	
	}
}

bool |NAME|Doc::isLastView() {
  return ((int) pViewList->count() == 1);
}


void |NAME|Doc::updateAllViews(|NAME|View *sender)
{
  |NAME|View *w;
  for(w=pViewList->first(); w!=0; w=pViewList->next())
  {
		w->update(sender);
  }

}

void |NAME|Doc::setPathName(const QString &name)
{
  m_filename=name;
	m_title=QFileInfo(name).fileName();
}

const QString& |NAME|Doc::pathName() const
{
  return m_filename;
}

void |NAME|Doc::setTitle(const QString &title)
{
  m_title=title;
}

const QString &|NAME|Doc::title() const
{
  return m_title;
}


void |NAME|Doc::closeDocument()
{
  |NAME|View *w;

  for(w=pViewList->first(); w!=0; w=pViewList->first())
  {
    if(!w->close())
			break;
  }
}

bool |NAME|Doc::newDocument()
{
  /////////////////////////////////////////////////
  // TODO: Add your document initialization code here
  /////////////////////////////////////////////////
  modified=false;
  return true;
}

bool |NAME|Doc::openDocument(const QString &filename, const char *format /*=0*/)
{

	QFile f( filename );
	if ( !f.open( IO_ReadOnly ) )
		return false;
  /////////////////////////////////////////////////
  // TODO: Add your document opening code here
  /////////////////////////////////////////////////
	f.close();
	
  modified=false;
  m_filename=filename;
	m_title=QFileInfo(f).fileName();
  return true;
}

bool |NAME|Doc::saveDocument(const QString &filename, const char *format /*=0*/)
{
	QFile f( filename );
	if ( !f.open( IO_WriteOnly ) )
		return false;

  /////////////////////////////////////////////////
  // TODO: Add your document saving code here
  /////////////////////////////////////////////////

  f.close();

  modified=false;
  m_filename=filename;
	m_title=QFileInfo(f).fileName();
  return true;
}

void |NAME|Doc::deleteContents()
{
  /////////////////////////////////////////////////
  // TODO: Add implementation to delete the document contents
  /////////////////////////////////////////////////

}
