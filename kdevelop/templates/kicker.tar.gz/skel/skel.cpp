#include <kglobal.h>
#include <klocale.h>
#include <kconfig.h>
#include <kapp.h>
#include <kmessagebox.h>

#include "|NAMELITTLE|.h"

extern "C"
{
  KPanelApplet* init( QWidget *parent, const QString configFile)
  {
    KGlobal::locale()->insertCatalogue("|NAMELITTLE|");
    return new |NAME|(configFile, KPanelApplet::Normal,
                      KPanelApplet::About | KPanelApplet::Help | KPanelApplet::Preferences,
                      parent, "|NAMELITTLE|");
  }
}

|NAME|::|NAME|(const QString& configFile, Type type, int actions, QWidget *parent, const char *name) 
       : KPanelApplet(configFile, type, actions, parent, name)
{
   // Get the current application configuration handle
   ksConfig = config();
   mainView = new myview(this);
   mainView->show();
}

|NAME|::~|NAME|()
{
}

void |NAME|::about()
{
   KMessageBox::information(0, i18n("This is an about box"));
}

void |NAME|::help()
{
   KMessageBox::information(0, i18n("This is a help box"));
}

void |NAME|::preferences()
{
   KMessageBox::information(0, i18n("This is a preferences box"));  
}

int |NAME|::widthForHeight( int height ) const
{
   return width();
}

int |NAME|::heightForWidth( int width ) const
{
   return height();
}

void |NAME|::resizeEvent( QResizeEvent *_Event)
{
   
}
