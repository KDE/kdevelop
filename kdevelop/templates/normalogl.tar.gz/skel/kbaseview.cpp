// include files for Qt
#include <qprinter.h>
#include <qpainter.h>

// application specific includes
#include <|NAMELITTLE|view.h>
#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|.h"

|NAME|View::|NAME|View(QWidget *parent, const char* name) : QGLWidget(parent, name)
{
	xRot = 15.0;
   yRot = -45.0;
   zRot = 0.0;
   scale = 1.0;
   object = 0;
}

|NAME|View::~|NAME|View()
{
	glDeleteLists(object, 1);
}


|NAME|Doc* |NAME|View::getDocument() const
{
	|NAME|App* theApp=(|NAME|App*)parentWidget();
	return theApp->getDocument();
}

void |NAME|View::print(QPrinter* m_pPrinter)
{
	QPainter printpainter;
	printpainter.begin(m_pPrinter);
	
	// TODO: add your printing code here
	
	printpainter.end();

}

void |NAME|View::paintGL(void)
{
	// TODO: modify or add to this code to make your objects visible

   glClear(GL_COLOR_BUFFER_BIT);
   
   glLoadIdentity();
   glTranslatef(0.0, 0.0, -10.0);
   glScalef(scale, scale, scale);
   
   glRotatef(xRot, 1.0, 0.0, 0.0);
   glRotatef(yRot, 0.0, 1.0, 0.0);
   glRotatef(zRot, 0.0, 0.0, 1.0);
   
   glColor3f(0.7, 0.7, 0.7);
   glCallList(object);
}

void |NAME|View::initializeGL(void)
{
	// TODO: modify or add to this code to initialize the OpenGL viewport and object lists

   glClearColor(0.95, 0.95, 0.95, 1.0);
   object = makeObject();
   glShadeModel(GL_SMOOTH);
}

void |NAME|View::resizeGL(int w, int h)
{
	// TODO: modify or add to this code to redimension after a window size change

   float ratio = (float)w / (float)h;

   glViewport(0, 0, (GLint)w, (GLint)h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glFrustum(-ratio, ratio, -1.0, 1.0, 5.0, 15.0);
   glMatrixMode(GL_MODELVIEW);
}

GLuint |NAME|View::makeObject(void)
{
	// TODO: modify or add to this code to create objects

   GLuint list;
   
   list = glGenLists(1);
   
   glNewList(list, GL_COMPILE);
   glLineWidth(1.0);
   
   glBegin(GL_LINES);
   
   glVertex3f(0.0, 0.0, 5.0);
   glVertex3f(0.0, 0.0, -5.0);

   glVertex3f(0.0, 5.0, 0.0);
   glVertex3f(0.0, -5.0, 0.0);
   
   glVertex3f(5.0, 0.0, 0.0);
   glVertex3f(-5.0, 0.0, 0.0);
   
   glEnd();
   glEndList();
   
   return(list);
}
