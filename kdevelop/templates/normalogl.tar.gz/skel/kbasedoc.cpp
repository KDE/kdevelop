// include files for Qt
#include <qdir.h>
#include <qfileinfo.h>
#include <qwidget.h>

// include files for KDE
#include <kapp.h>
#include <kmsgbox.h>

// application specific includes
#include <|NAMELITTLE|doc.h>
#include "|NAMELITTLE|.h"
#include "|NAMELITTLE|view.h"

QList<|NAME|View>* |NAME|Doc::viewList = 0L;

|NAME|Doc::|NAME|Doc(QWidget *parent, const char* name):QObject(parent, name)
{
	if( !viewList )
		viewList = new QList<|NAME|View>;
	viewList->setAutoDelete(true);
}

|NAME|Doc::~|NAME|Doc()
{
}

void |NAME|Doc::addView(|NAME|View* m_pView)
{
	viewList->append(m_pView);
}

void |NAME|Doc::removeView(|NAME|View* m_pView)
{
	viewList->remove(m_pView);
}
const QString& |NAME|Doc::getPathName() const
{
	return m_path;
}

void |NAME|Doc::slotUpdateAllViews(|NAME|View* pSender)
{
	|NAME|View* w;
	if(viewList)
	{
		for( w = viewList->first(); w; w = viewList->next() )
		{ if( w != pSender)
			w->repaint();
		}
	}

}

void |NAME|Doc::pathName( const char* path_name)
{
	m_path=path_name;
}
void |NAME|Doc::title( const char* title)
{
	m_title=title;
}

const QString& |NAME|Doc::getTitle() const
{
	return m_title;
}

bool |NAME|Doc::saveModified()
{
	if(b_modified)
	{
		|NAME|App* win=(|NAME|App*) parent();
  		int want_save = KMsgBox::yesNoCancel(win,
  									i18n("Warning"),	i18n("The current file has been modified.\nDo you want to save it?"));
   	switch(want_save)
    	{
    		case 1:
    			if(m_title == "Untitled")
    				win->slotFileSaveAs();
    			else
	     			saveDocument(getPathName()+getTitle());
       	
       		deleteContents();
        		return true;
        		break;
  			case 2:
    			setModified(false);
      		deleteContents();
  				return true;
  				break;	
  			case 3:
  				return false;
  				break;
  			default:
  				return false;
  				break;
  		}
	}
	else
		return true;
}

void |NAME|Doc::closeDocument()
{
	deleteContents();
}

bool |NAME|Doc::newDocument()
{
	
	/////////////////////////////////////////////////
	// TODO: Add your document initialization code here
	/////////////////////////////////////////////////
	b_modified=false;
	m_path=QDir::homeDirPath();
	m_title="Untitled";
	return true;
}

bool |NAME|Doc::openDocument(const char* filename, const char* format)
{
	QFileInfo fileInfo(filename);
	m_title=fileInfo.fileName();
	m_path=fileInfo.absFilePath();	
	/////////////////////////////////////////////////
	// TODO: Add your document opening code here
	/////////////////////////////////////////////////
	
	b_modified=false;
	return true;
}

bool |NAME|Doc::saveDocument(const char* filename, const char* format)
{

	/////////////////////////////////////////////////
	// TODO: Add your document saving code here
	/////////////////////////////////////////////////

	b_modified=false;
	return true;
}

void |NAME|Doc::deleteContents()
{
	/////////////////////////////////////////////////
	// TODO: Add implementation to delete the document contents
	/////////////////////////////////////////////////

}
