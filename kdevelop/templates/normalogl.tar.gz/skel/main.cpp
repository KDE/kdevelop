
#include "|NAMELITTLE|.h"
 
int main(int argc, char* argv[])
{ 
  KApplication app(argc,argv,"|NAMELITTLE|");
 
  if (app.isRestored())
    { 
      RESTORE(|NAME|App);
    }
  else 
    {
      |NAME|App* |NAMELITTLE| = new |NAME|App;
      |NAMELITTLE|->show();
      if(argc > 1)
      {
      	|NAMELITTLE|->openDocumentFile(argv[1]);
		}
    }
  return app.exec();
}  
