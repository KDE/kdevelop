#ifndef BANKDOC_H
#define BANKDOC_H

// include files for QT
#include <qobject.h>

// application specific includes

/**
  * the Document Class
  */

class BankDoc : public QObject  {
  Q_OBJECT
public: 
  BankDoc();
  ~BankDoc();
  void newDoc();
  bool save();
  bool saveAs(QString filename);
  bool load(QString filename);
  bool isModified();

  signals:
  void documentChanged();

protected:
  bool b_modified;
};


#endif
