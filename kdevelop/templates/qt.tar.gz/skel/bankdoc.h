#ifndef |NAMEBIG|DOC_H
#define |NAMEBIG|DOC_H

// include files for QT
#include <qobject.h>

// application specific includes

/**
  * the Document Class
  */

class |NAME|Doc : public QObject  {
  Q_OBJECT
public: 
  |NAME|Doc();
  ~|NAME|Doc();
  void newDoc();
  bool save();
  bool saveAs(QString filename);
  bool load(QString filename);
  bool isModified();

  signals:
  void documentChanged();

protected:
  bool b_modified;
};


#endif
