#ifndef BANKVIEW_H
#define BANKVIEW_H

// include files for QT
#include <qwidget.h>

// application specific includes
#include "bankdoc.h"

/**
 * This class provides an incomplete base for your application view. 
 */

class BankView : public QWidget  {
   Q_OBJECT
public: 
   BankView(QWidget *parent=0, BankDoc* doc=0);
  ~BankView();
  
protected slots:

void slotDocumentChanged();
  
};

#endif
