
#include <qapplication.h>
#include <qfont.h>

#include "|NAMELITTLE|.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  a.setFont(QFont("helvetica", 12));
  /* uncomment the following line, if you want a Windows 95 look*/
  // a.setStyle(WindowsStyle);
    
  |NAME| *|NAMELITTLE|=new |NAME|();
  a.setMainWidget(|NAMELITTLE|);

  |NAMELITTLE|->setCaption("Document 1");
  |NAMELITTLE|->show();

  return a.exec();
}
