

#include <qapplication.h>
#include <qfont.h>

#include "bank.h"

int main( int argc, char ** argv ) {
  QApplication a( argc, argv );
  a.setFont(QFont("helvetica",12));
/* uncomment it, if you want a Windows 95 look*/
//  a.setStyle(WindowsStyle);
    
  Bank * bank = new Bank();
  a.setMainWidget(bank);
  bank->setCaption( "Document 1" );
  bank->show();
  return a.exec();
}
