#include "bank.h"
#include "filesave.xpm"
#include "fileopen.xpm"
#include "filenew.xpm"

Bank::Bank()
{
  setCaption("Bank " VERSION);
  
  ///////////////////////////////////////////////////////////////////
  // call inits to invoke all other construction parts
  initMenuBar();
  initToolBar();
  initStatusBar();

  initDoc();
  initView();  
}

Bank::~Bank(){
}

void Bank::initMenuBar()
{
  ///////////////////////////////////////////////////////////////////
  // MENUBAR  

  ///////////////////////////////////////////////////////////////////
  // menuBar entry file_menu
  file_menu = new QPopupMenu();
  file_menu->insertItem("&New",this,SLOT(slotFileNew()),CTRL+Key_N, ID_FILE_NEW );
  file_menu->insertItem("&Open...",this,SLOT(slotFileOpen()),CTRL+Key_O, ID_FILE_OPEN );
  file_menu->insertSeparator();
  file_menu->insertItem("&Save",this,SLOT(slotFileSave()),CTRL+Key_S, ID_FILE_SAVE );
  file_menu->insertItem("Save &as",this,SLOT(slotFileSaveAs()),0, ID_FILE_SAVE_AS);
  file_menu->insertItem("&Close",this,SLOT(slotFileClose()),CTRL+Key_W, ID_FILE_CLOSE );
  file_menu->insertSeparator();
  file_menu->insertItem("&Print",this,SLOT(slotFilePrint()),CTRL+Key_P, ID_FILE_PRINT );
  file_menu->insertSeparator();
  file_menu->insertItem("E&xit",this,SLOT(slotFileQuit()),CTRL+Key_Q, ID_FILE_QUIT );

  ///////////////////////////////////////////////////////////////////
  // menuBar entry edit_menu
  edit_menu = new QPopupMenu();
  edit_menu->insertItem("Cu&t",this,SLOT(slotEditCut()),CTRL+Key_X, ID_EDIT_CUT );
  edit_menu->insertItem("&Copy",this,SLOT(slotEditCopy()),CTRL+Key_C, ID_EDIT_COPY );
  edit_menu->insertItem("&Paste",this,SLOT(slotEditPaste()),CTRL+Key_V, ID_EDIT_PASTE );
 
  
  ///////////////////////////////////////////////////////////////////
  // menuBar entry view_menu
  view_menu = new QPopupMenu();
  view_menu->setCheckable(true);
  view_menu->insertItem("Tool&bar",this,SLOT(slotViewToolBar()),0, ID_VIEW_TOOLBAR);
  view_menu->insertItem("&Statusbar",this,SLOT(slotViewStatusBar()),0, ID_VIEW_STATUSBAR );

  view_menu->setItemChecked(ID_VIEW_TOOLBAR, true);
  view_menu->setItemChecked(ID_VIEW_STATUSBAR,true);

  ///////////////////////////////////////////////////////////////////
  // EDIT YOUR APPLICATION SPECIFIC MENUENTRIES HERE
  
  ///////////////////////////////////////////////////////////////////
  // menuBar entry help_menu
  help_menu = new QPopupMenu();
  help_menu->insertItem("About...",this,SLOT(slotHelpAbout()),0,ID_HELP_ABOUT);


  ///////////////////////////////////////////////////////////////////
  // MENUBAR CONFIGURATION
  // set menuBar() the current menuBar 

  menuBar()->insertItem("&File", file_menu);
  menuBar()->insertItem("&Edit", edit_menu);
  menuBar()->insertItem("&View", view_menu);
  menuBar()->insertSeparator();
  menuBar()->insertItem("&Help", help_menu);
  
  ///////////////////////////////////////////////////////////////////
  // CONNECT THE SUBMENU SLOTS WITH SIGNALS

  connect(file_menu,SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  connect(edit_menu,SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  connect(view_menu,SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  connect(help_menu,SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  
}
void Bank::initToolBar()
{

  ///////////////////////////////////////////////////////////////////
  // TOOLBAR
  QPixmap openIcon,saveIcon,newIcon;

  file_toolbar = new QToolBar( this, "file operations" );
 
  newIcon = QPixmap( filenew );
  QToolButton * fileNew = new QToolButton( newIcon, "New File", 0,this, SLOT(slotFileNew()),
					   file_toolbar);

  openIcon = QPixmap( fileopen );
  QToolButton * fileOpen = new QToolButton( openIcon, "Open File", 0,this, SLOT(slotFileOpen()),
					    file_toolbar);

  saveIcon = QPixmap( filesave );
  QToolButton * fileSave = new QToolButton( saveIcon, "Save File", 0,this, SLOT(slotFileSave()),
					    file_toolbar);
  
  
  file_toolbar->addSeparator();
  (void)QWhatsThis::whatsThisButton( file_toolbar );
  QWhatsThis::add(fileNew,"Click this button to create a new file.\n\n"
		   "You can also select the New command from the File menu.");
  QWhatsThis::add(fileOpen,"Click this button to open a new file.\n\n"
		   "You can also select the Open command from the File menu.");
  QWhatsThis::add(fileSave,"Click this button to save the file you are "
		  "editing.  You will be prompted for a file name.\n\n"
		  "You can also select the Save command from the File menu.");
  
}

void Bank::initStatusBar()
{
  ///////////////////////////////////////////////////////////////////
  //STATUSBAR
  statusBar()->message( IDS_DEFAULT, 2000 );
}

void Bank::initDoc(){
   doc = new BankDoc();
}

void Bank::initView()
{ 
  ////////////////////////////////////////////////////////////////////
  // set the main widget here
  view = new BankView(this,doc);
  setCentralWidget( view );
}

bool Bank::queryExit()
{
  int exit=QMessageBox::information(this,"Quit...","Really Quit?",QMessageBox::Ok,QMessageBox::Cancel);

    if(exit==1){
      return true;
    }
    else{
      return false;
    }
}

/////////////////////////////////////////////////////////////////////
// SLOT IMPLEMENTATION
/////////////////////////////////////////////////////////////////////


void Bank::slotFileNew()
{
  statusBar()->message("Creating new file...");
  doc->newDoc();
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotFileOpen()
{
  statusBar()->message("Opening file...");

  QString fileName = QFileDialog::getOpenFileName(0,0,this);
  if ( !fileName.isEmpty() ){
     doc->load( fileName );
     setCaption( fileName );
     QString message = "Loaded document: " + fileName;
     statusBar()->message( message, 2000 );
  }
  else{
    statusBar()->message( "Opening aborted", 2000 );
  }
}


void Bank::slotFileSave()
{
  statusBar()->message("Saving file...");
  doc->save();
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotFileSaveAs()
{
  statusBar()->message("Saving file under new filename...");
  QString fn = QFileDialog::getSaveFileName(0,0,this);
  if ( !fn.isEmpty() ){
    doc->saveAs( fn );
  }
  else{
    statusBar()->message( "Opening aborted", 2000 );
  }
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotFileClose()
{
  statusBar()->message("Closing file...");
  
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotFilePrint()
{
  statusBar()->message("Printing...");
  QPrinter printer;
  if (printer.setup(this))
    {
      QPainter painter;
      painter.begin( &printer );

      ///////////////////////////////////////////////////////////////////
      // TODO: Define printing by using the QPainter methods here

      painter.end();
    };
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotFileQuit()
{ 
  ///////////////////////////////////////////////////////////////////
  // exits the Application
  if(doc->isModified()){
    if(this->queryExit())
      {
	qApp->quit();
      }
    else{
      statusBar()->message(IDS_DEFAULT);
    }
  }
  else{
    qApp->quit();
  }
}

void Bank::slotEditCut()
{
  statusBar()->message("Cutting selection...");

  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotEditCopy()
{
  statusBar()->message("Copying selection to Clipboard...");
  
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotEditPaste()
{
  statusBar()->message("Inserting Clipboard contents...");
  
  statusBar()->message(IDS_DEFAULT);
}


void Bank::slotViewToolBar()
{
  ///////////////////////////////////////////////////////////////////
  // turn Toolbar on or off
  
  if ( file_toolbar->isVisible() ) {
    file_toolbar->hide();
    view_menu->setItemChecked( ID_VIEW_TOOLBAR, false);
  } 
  else {
    file_toolbar->show();
    view_menu->setItemChecked( ID_VIEW_TOOLBAR, true );
  }  
  statusBar()->message(IDS_DEFAULT);

}

void Bank::slotViewStatusBar()
{
  ///////////////////////////////////////////////////////////////////
  //turn Statusbar on or off
  
  if ( statusBar()->isVisible() ) {
    statusBar()->hide();
    view_menu->setItemChecked( ID_VIEW_STATUSBAR, false );
  }
  else {
    statusBar()->show();
    view_menu->setItemChecked( ID_VIEW_STATUSBAR, true );
  }
  
  statusBar()->message(IDS_DEFAULT);
}

void Bank::slotHelpAbout(){
  QMessageBox::about(this,"About...", IDS_APP_ABOUT " \n(w) 1999 by AUTHOR");
}

void Bank::slotStatusHelpMsg(const char *text)
{
  ///////////////////////////////////////////////////////////////////
  // change status message of whole statusbar temporary (text, msec)
  statusBar()->message(text, 2000);
}

void Bank::statusCallback(int id_){
  switch (id_) {
    
  case ID_FILE_NEW        :  slotStatusHelpMsg("Creates a new document");break;
  case ID_FILE_OPEN       :  slotStatusHelpMsg("Opens an existing document");break;
  case ID_FILE_SAVE       :  slotStatusHelpMsg("Save the actual document");break;
  case ID_FILE_SAVE_AS    :  slotStatusHelpMsg("Save the actual document");break;
  case ID_FILE_CLOSE      :  slotStatusHelpMsg("Closes the actual file");break;
  case ID_FILE_QUIT       :  slotStatusHelpMsg("Exits the program");break;
  case ID_EDIT_CUT        :  slotStatusHelpMsg("Cuts the selected section and puts it to the clipboard")
			      ;break;
  case ID_EDIT_COPY       :  slotStatusHelpMsg("Copys the selected section to the clipboard");break;
  case ID_EDIT_PASTE      :  slotStatusHelpMsg("Pastes the clipboard contents to actual position");break;
  case ID_EDIT_SELECT_ALL :  slotStatusHelpMsg("Selects the whole document contents");break;
  case ID_VIEW_TOOLBAR    :  slotStatusHelpMsg("Enables / disables the actual Toolbar");break;
  case ID_VIEW_STATUSBAR  :  slotStatusHelpMsg("Enables / disables the Statusbar");break;   
  case ID_HELP_ABOUT      :  slotStatusHelpMsg("Shows an aboutbox");break;  
  }
}

