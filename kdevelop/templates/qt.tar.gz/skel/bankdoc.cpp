
#include "bankdoc.h"

BankDoc::BankDoc(){
  b_modified = false;
}
BankDoc::~BankDoc(){
}
bool BankDoc::newDoc(){
}
bool BankDoc::save(){
}
bool BankDoc::saveAs(QString filename){
}
bool BankDoc::load(QString filename){
}
bool BankDoc::isModified(){
  return b_modified;
}
