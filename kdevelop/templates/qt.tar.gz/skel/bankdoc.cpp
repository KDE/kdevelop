
#include "bankdoc.h"

BankDoc::BankDoc(){
  b_modified = false;
}
BankDoc::~BankDoc(){
}
void BankDoc::newDoc(){
}
bool BankDoc::save(){
    return true;
}
bool BankDoc::saveAs(QString filename){
    return true;
}
bool BankDoc::load(QString filename){
    emit documentChanged();
    return true;
}
bool BankDoc::isModified(){
  return b_modified;
}
