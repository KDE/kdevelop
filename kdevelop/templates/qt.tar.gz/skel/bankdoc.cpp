
#include "|NAMELITTLE|doc.h"

|NAME|Doc::|NAME|Doc(){
  b_modified = false;
}
|NAME|Doc::~|NAME|Doc(){
}
void |NAME|Doc::newDoc(){
}
bool |NAME|Doc::save(){
    return true;
}
bool |NAME|Doc::saveAs(QString filename){
    return true;
}
bool |NAME|Doc::load(QString filename){
    emit documentChanged();
    return true;
}
bool |NAME|Doc::isModified(){
  return b_modified;
}
