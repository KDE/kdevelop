
#include "|NAMELITTLE|view.h"

|NAME|View::|NAME|View(QWidget *parent,|NAME|Doc* doc) : QWidget(parent) {
  /** connect doc with the view*/
  connect(doc,SIGNAL(documentChanged()),this,SLOT(slotDocumentChanged()));
}
|NAME|View::~|NAME|View(){
}
void |NAME|View::slotDocumentChanged(){
  //TODO update the view

}
