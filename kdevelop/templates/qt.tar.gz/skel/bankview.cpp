
#include "bankview.h"

BankView::BankView(QWidget *parent,BankDoc* doc) : QWidget(parent) {
  /** connect doc with the view*/
  connect(doc,SIGNAL(documentChanged()),this,SLOT(slotDocumentChanged()));
}
BankView::~BankView(){
}
void BankView::slotDocumentChanged(){
  //TODO update the view

}
