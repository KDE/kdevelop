
#ifndef |NAMEBIG|VIEW_H
#define |NAMEBIG|VIEW_H

// include files for QextMDI
#include <qextmdichildview.h>

// application specific includes
#include "|NAMELITTLE|doc.h"
#include "tabprocessingeditwidget.h"

/**
 * This class provides an incomplete base for your application view. 
 */

class |NAME|View : public QextMdiChildView
{
  Q_OBJECT
public:
   |NAME|View(QWidget *parent=0, |NAME|Doc* doc=0, QString title = "Document");
   ~|NAME|View();

   TabProcessingEditWidget* tew;
protected slots:
   void slotDocumentChanged();
  
};

#endif
