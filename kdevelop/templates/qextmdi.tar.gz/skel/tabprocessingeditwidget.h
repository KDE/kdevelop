
#ifndef TABPROCESSINGEDITWIDGET_H
#define TABPROCESSINGEDITWIDGET_H

#include <qmultilineedit.h>

/**
  *@author Falk Brettschneider
  */

class TabProcessingEditWidget : public QMultiLineEdit
{
public: 
	TabProcessingEditWidget(QWidget* parent, const char* name);
	~TabProcessingEditWidget();
protected:
   virtual bool event( QEvent *e );
   virtual void keyPressEvent(QKeyEvent *ke);
};

#endif
