#include <qapplication.h>
#include <qfont.h>
#include <qwindowsstyle.h>
#include <qplatinumstyle.h>

#include "|NAMELITTLE|.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  //a.setFont(QFont("helvetica", 12));
  //a.setStyle( new QWindowsStyle);
  a.setStyle( new QPlatinumStyle);
    
  |NAME| *|NAMELITTLE|=new |NAME|();
  a.setMainWidget(|NAMELITTLE|);

  |NAMELITTLE|->setCaption("|NAME|");
  |NAMELITTLE|->show();
  |NAMELITTLE|->resize(600,400);

  return a.exec();
}
