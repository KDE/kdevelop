#ifndef NO_KDE2
#include <kapp.h>
   KApplication* theApp;
#else
#include <qapplication.h>
   QApplication* theApp;
#endif

#include <qfont.h>
#include <qwindowsstyle.h>
#include <qplatinumstyle.h>

#include "|NAMELITTLE|.h"

int main(int argc, char *argv[])
{
#ifndef NO_KDE2
  KApplication a(argc,argv,"KFourChildren");
#else
  QApplication a(argc,argv);
#endif
  //a.setFont(QFont("helvetica", 12));
  /* uncomment the following line, if you want a Windows 95 look*/
  //a.setStyle( new QWindowsStyle);
  a.setStyle( new QPlatinumStyle);
    
  |NAME| *|NAMELITTLE|=new |NAME|();
  a.setMainWidget(|NAMELITTLE|);

  |NAMELITTLE|->setCaption("|NAME|");
  |NAMELITTLE|->show();
  |NAMELITTLE|->resize(800,600);

  return a.exec();
}
