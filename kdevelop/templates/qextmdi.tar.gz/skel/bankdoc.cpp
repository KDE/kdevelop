
#include "|NAMELITTLE|doc.h"

|NAME|Doc::|NAME|Doc()
{
  modified = FALSE;
}

|NAME|Doc::~|NAME|Doc()
{
}

void |NAME|Doc::newDoc()
{
}

bool |NAME|Doc::save()
{
  return TRUE;
}

bool |NAME|Doc::saveAs(const QString &/*filename*/)
{
  return TRUE;
}

bool |NAME|Doc::load(const QString &/*filename*/)
{
  emit documentChanged();
  return TRUE;
}

bool |NAME|Doc::isModified() const
{
  return modified;
}
