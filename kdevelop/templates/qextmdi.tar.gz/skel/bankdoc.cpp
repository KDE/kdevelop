
#include "|NAMELITTLE|doc.h"

|NAME|Doc::|NAME|Doc()
{
  modified = false;
}

|NAME|Doc::~|NAME|Doc()
{
}

void |NAME|Doc::newDoc()
{
}

bool |NAME|Doc::save()
{
  return true;
}

bool |NAME|Doc::saveAs(const QString &filename)
{
  return true;
}

bool |NAME|Doc::load(const QString &filename)
{
  emit documentChanged();
  return true;
}

bool |NAME|Doc::isModified() const
{
  return modified;
}
