#include <qtextstream.h>

#include "|NAMELITTLE|.h"
#include "filesave.xpm"
#include "fileopen.xpm"
#include "filenew.xpm"

|NAME|::|NAME|() : QextMdiMainFrm(0),
  m_currentNumber(1)
{
  setCaption("|NAME| ");
  
  ///////////////////////////////////////////////////////////////////
  // call inits to invoke all other construction parts
  initMenuBar();
  initToolBar();
  initStatusBar();

  initDoc();
  initView();
}

|NAME|::~|NAME|()
{
}

void |NAME|::initMenuBar()
{
  ///////////////////////////////////////////////////////////////////
  // MENUBAR

  ///////////////////////////////////////////////////////////////////
  // menuBar entry fileMenu

  fileMenu=new QPopupMenu();
  fileMenu->insertItem("&New", this, SLOT(slotFileNew()), CTRL+Key_N, ID_FILE_NEW);
  fileMenu->insertItem("Ne&w Detached", this, SLOT(slotFileNewDetached()), CTRL+Key_D, ID_FILE_NEW_DETACHED);

  fileMenu->insertItem("&Open...", this, SLOT(slotFileOpen()), CTRL+Key_O, ID_FILE_OPEN);
  fileMenu->insertSeparator();
  fileMenu->insertItem("&Save", this, SLOT(slotFileSave()), CTRL+Key_S, ID_FILE_SAVE);
  fileMenu->insertItem("Save &as...", this, SLOT(slotFileSaveAs()), 0, ID_FILE_SAVE_AS);
  fileMenu->insertItem("&Close", this, SLOT(slotFileClose()), CTRL+Key_W, ID_FILE_CLOSE);
  fileMenu->insertSeparator();
  fileMenu->insertItem("&Print", this, SLOT(slotFilePrint()), CTRL+Key_P, ID_FILE_PRINT);
  fileMenu->insertSeparator();
  fileMenu->insertItem("E&xit", this, SLOT(slotFileQuit()), CTRL+Key_Q, ID_FILE_QUIT);

  ///////////////////////////////////////////////////////////////////
  // menuBar entry editMenu
  editMenu=new QPopupMenu();
  editMenu->insertItem("Cu&t", this, SLOT(slotEditCut()), CTRL+Key_X, ID_EDIT_CUT);
  editMenu->insertItem("&Copy", this, SLOT(slotEditCopy()), CTRL+Key_C, ID_EDIT_COPY);
  editMenu->insertItem("&Paste", this, SLOT(slotEditPaste()), CTRL+Key_V, ID_EDIT_PASTE);
 
  
  ///////////////////////////////////////////////////////////////////
  // menuBar entry viewMenu
  viewMenu=new QPopupMenu();
  viewMenu->setCheckable(TRUE);
  viewMenu->insertItem("&Toolbar", this, SLOT(slotViewToolBar()), 0, ID_VIEW_TOOLBAR);
  viewMenu->insertItem("&Statusbar", this, SLOT(slotViewStatusBar()), 0, ID_VIEW_STATUSBAR);
  viewMenu->insertItem("T&askbar", this, SLOT(slotViewTaskBar()), 0, ID_VIEW_TASKBAR);

  viewMenu->setItemChecked(ID_VIEW_TOOLBAR, TRUE);
  viewMenu->setItemChecked(ID_VIEW_STATUSBAR, TRUE);
  viewMenu->setItemChecked(ID_VIEW_TASKBAR, TRUE);

  ///////////////////////////////////////////////////////////////////
  // EDIT YOUR APPLICATION SPECIFIC MENUENTRIES HERE
  
  ///////////////////////////////////////////////////////////////////
  // menuBar entry helpMenu
  helpMenu=new QPopupMenu();
  helpMenu->insertItem("About...", this, SLOT(slotHelpAbout()), 0, ID_HELP_ABOUT);


  ///////////////////////////////////////////////////////////////////
  // MENUBAR CONFIGURATION
  // set menuBar() the current menuBar 

  menuBar()->insertItem("&File", fileMenu);
  menuBar()->insertItem("&Edit", editMenu);
  menuBar()->insertItem("&View", viewMenu);
  menuBar()->insertItem("&Window", windowMenu());
  //menuBar()->insertSeparator();
  menuBar()->insertItem("&Help", helpMenu);
  
  ///////////////////////////////////////////////////////////////////
  // CONNECT THE SUBMENU SLOTS WITH SIGNALS

  QObject::connect(fileMenu, SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  QObject::connect(editMenu, SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  QObject::connect(viewMenu, SIGNAL(highlighted(int)), SLOT(statusCallback(int)));
  QObject::connect(helpMenu, SIGNAL(highlighted(int)), SLOT(statusCallback(int)));

  setMenuForSDIModeSysButtons( menuBar());
}

void |NAME|::initToolBar()
{
  ///////////////////////////////////////////////////////////////////
  // TOOLBAR
  QPixmap openIcon, saveIcon, newIcon, newDetIcon;

  fileToolbar = new QToolBar(this, "file operations");
 
  newIcon = QPixmap(filenew);
  QToolButton *fileNew = new QToolButton(newIcon, "New Attached File", 0, this,
                                          SLOT(slotFileNew()), fileToolbar);

  newDetIcon = QPixmap(filenew);
  QToolButton *fileDetNew = new QToolButton(newDetIcon, "New Detached File", 0, this,
                                          SLOT(slotFileNewDetached()), fileToolbar);

  openIcon = QPixmap(fileopen);
  QToolButton *fileOpen = new QToolButton(openIcon, "Open File", 0, this,
                                          SLOT(slotFileOpen()), fileToolbar);

  saveIcon = QPixmap(filesave);
  QToolButton *fileSave = new QToolButton(saveIcon, "Save File", 0, this,
                                          SLOT(slotFileSave()), fileToolbar);

	QLabel *space = new QLabel( fileToolbar, "space");
	space->setText("");
	fileToolbar->setStretchableWidget(space);
  
  fileToolbar->addSeparator();
  QWhatsThis::whatsThisButton(fileToolbar);
  QWhatsThis::add(fileNew,"Click this button to create a new attached (docked) file within the MDI area widget.\n\n"
                  "You can also select the appropriate New command from the File menu.");
  QWhatsThis::add(fileDetNew,"Click this button to create a new detached (undocked) file on the desktop.\n\n"
                  "You can also select the appropriate New command from the File menu.");
  QWhatsThis::add(fileOpen,"Click this button to open a new file.\n\n"
                  "You can also select the Open command from the File menu.");
  QWhatsThis::add(fileSave,"Click this button to save the file you are "
                  "editing. You will be prompted for a file name.\n\n"
                  "You can also select the Save command from the File menu.");
}

void |NAME|::initStatusBar()
{
  ///////////////////////////////////////////////////////////////////
  //STATUSBAR
  statusBar()->message(IDS_STATUS_DEFAULT, 2000);
}

void |NAME|::initDoc()
{
	///////////////////////////////////////////////////////////////////
	// set an example doc here
  doc=new |NAME|Doc();
}

void |NAME|::initView()
{ 
  ////////////////////////////////////////////////////////////////////
  // set an example MDI widget here
  view=new |NAME|View(0L, doc); // Do not use "this" as parent! Causes problems if you are using maximum sizes...
  //QRect r(0,0,400,200);
  addWindow(view);

//	addWindow( view, TRUE, TRUE, FALSE, &r);
}

/////////////////////////////////////////////////////////////////////
// SLOT IMPLEMENTATION
/////////////////////////////////////////////////////////////////////


void |NAME|::slotFileNew()
{
  statusBar()->message("Creating new file...");

	// !This example framework doesn't control doc and view pointers!
	// but pressing the close button will already delete pView...
	// take pDoc under control in your real application...
  	|NAME|Doc* pDoc = new |NAME|Doc();
	QString numberString;
	numberString.setNum( m_currentNumber++);
  	|NAME|View* pView = new |NAME|View(0L, pDoc, "Document" + numberString);
  	
	addWindow( pView);

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotFileOpen()
{
   statusBar()->message("Opening file...");

   QString fileName = QFileDialog::getOpenFileName(0,0,this);
   QString text;
   if (!fileName.isEmpty())
   {
      |NAME|Doc* pDoc = new |NAME|Doc();
      QFile f(fileName);
      if ( f.open(IO_ReadOnly) ) {     // file opened successfully
         QTextStream t( &f );          // use a text stream
         while ( !t.eof() ) {          // until end of file...
            text = text + t.readLine() + "\n";  // line of text
          }
          f.close();
      }
      setCaption(fileName);
      QString message="Loaded document: " + fileName;
      statusBar()->message(message, 2000);
   	QString numberString;
	   numberString.setNum( m_currentNumber++);
      |NAME|View* pView = new |NAME|View(0L, pDoc, "Document" + numberString);
      if( !text.isEmpty())
         pView->tew->setText(text);
      addWindow( pView);
   }
   else
   {
      statusBar()->message("Opening aborted", 2000);
   }
}


void |NAME|::slotFileSave()
{
  statusBar()->message("Saving file...");
  doc->save();
  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotFileSaveAs()
{
  statusBar()->message("Saving file under new filename...");
  QString fn = QFileDialog::getSaveFileName(0, 0, this);
  if (!fn.isEmpty())
  {
    doc->saveAs(fn);
  }
  else
  {
    statusBar()->message("Saving aborted", 2000);
  }

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotFileClose()
{
  statusBar()->message("Closing file...");

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotFilePrint()
{
  statusBar()->message("Printing...");
  QPrinter printer;
  if (printer.setup(this))
  {
    QPainter painter;
    painter.begin(&printer);

    ///////////////////////////////////////////////////////////////////
    // TODO: Define printing by using the QPainter methods here

    painter.end();
  };

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotFileQuit()
{ 
  statusBar()->message("Exiting application...");
  ///////////////////////////////////////////////////////////////////
  // exits the Application
  qApp->quit();
}

void |NAME|::slotEditCut()
{
  statusBar()->message("Cutting selection...");

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotEditCopy()
{
  statusBar()->message("Copying selection to clipboard...");
  
  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotEditPaste()
{
  statusBar()->message("Inserting clipboard contents...");
  
  statusBar()->message(IDS_STATUS_DEFAULT);
}


void |NAME|::slotViewToolBar()
{
  statusBar()->message("Toggle toolbar...");
  ///////////////////////////////////////////////////////////////////
  // turn toolbar on or off
  
  if (fileToolbar->isVisible())
  {
    fileToolbar->hide();
    viewMenu->setItemChecked(ID_VIEW_TOOLBAR, FALSE);
  } 
  else
  {
    fileToolbar->show();
    viewMenu->setItemChecked(ID_VIEW_TOOLBAR, TRUE);
  };

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotViewStatusBar()
{
  statusBar()->message("Toggle statusbar...");
  ///////////////////////////////////////////////////////////////////
  //turn statusbar on or off
  
  if (statusBar()->isVisible())
  {
    statusBar()->hide();
    viewMenu->setItemChecked(ID_VIEW_STATUSBAR, FALSE);
  }
  else
  {
    statusBar()->show();
    viewMenu->setItemChecked(ID_VIEW_STATUSBAR, TRUE);
  }
  
  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotViewTaskBar()
{
  statusBar()->message("Toggle taskbar...");
  ///////////////////////////////////////////////////////////////////
  //turn statusbar on or off

  if (m_pTaskBar->isVisible())
  {
    hideViewTaskBar();
    viewMenu->setItemChecked(ID_VIEW_TASKBAR, FALSE);
  }
  else
  {
    showViewTaskBar();
    viewMenu->setItemChecked(ID_VIEW_TASKBAR, TRUE);
  }

  statusBar()->message(IDS_STATUS_DEFAULT);
}

void |NAME|::slotHelpAbout()
{
  QMessageBox::about(this,"About...",
                     IDS_APP_ABOUT );
}

void |NAME|::slotStatusHelpMsg(const QString &text)
{
  ///////////////////////////////////////////////////////////////////
  // change status message of whole statusbar temporary (text, msec)
  statusBar()->message(text, 2000);
}

void |NAME|::statusCallback(int id_)
{
  switch (id_)
  {
    case ID_FILE_NEW:
         slotStatusHelpMsg("Creates a new document");
         break;

    case ID_FILE_OPEN:
         slotStatusHelpMsg("Opens an existing document");
         break;

    case ID_FILE_SAVE:
         slotStatusHelpMsg("Saves the actual document");
         break;

    case ID_FILE_SAVE_AS:
         slotStatusHelpMsg("Saves the actual document as...");
         break;

    case ID_FILE_CLOSE:
         slotStatusHelpMsg("Closes the actual document");
         break;

    case ID_FILE_PRINT:
         slotStatusHelpMsg("Prints out the actual document");
         break;

    case ID_FILE_QUIT:
         slotStatusHelpMsg("Quits the application");
         break;

    case ID_EDIT_CUT:
         slotStatusHelpMsg("Cuts the selected section and puts it to the clipboard");
         break;

    case ID_EDIT_COPY:
         slotStatusHelpMsg("Copies the selected section to the clipboard");
         break;

    case ID_EDIT_PASTE:
         slotStatusHelpMsg("Pastes the clipboard contents to actual position");
         break;

    case ID_EDIT_SELECT_ALL:
         slotStatusHelpMsg("Selects the whole document contents");
         break;

    case ID_VIEW_TOOLBAR:
         slotStatusHelpMsg("Enables/disables the toolbar");
         break;

    case ID_VIEW_STATUSBAR:
         slotStatusHelpMsg("Enables/disables the statusbar");
         break;

    case ID_VIEW_TASKBAR:
         slotStatusHelpMsg( "Enables / disables the taskbar");
         break;

    case ID_HELP_ABOUT:
         slotStatusHelpMsg("Shows an aboutbox");
         break;
  }
}

/**
 * undocks all view windows (unix-like)
 */
void |NAME|::switchToToplevelMode()
{
   QextMdiMainFrm::switchToToplevelMode();
   setMinimumHeight(height()-m_pMdi->height());
   resize( width(), height()-m_pMdi->height());
}

/** just additionally fits the system menu button position to the menu position */
void |NAME|::resizeEvent ( QResizeEvent *e)
{
   QextMdiMainFrm::resizeEvent( e);
   setSysButtonsAtMenuPosition();
}

/** open a window detached form the MDI */
void |NAME|::slotFileNewDetached(){
   statusBar()->message("Creating new file...");
 
   |NAME|Doc* pDoc = new |NAME|Doc();
   QString numberString;
   numberString.setNum( m_currentNumber++);

   |NAME|View* pView = new |NAME|View( 0L, pDoc, "Document" + numberString);
   addWindow( pView, QRect( 20*m_currentNumber, 20*m_currentNumber, 300, 150), QextMdi::Detach);

   statusBar()->message(IDS_STATUS_DEFAULT);
}
