/***************************************************************************
                          tabprocessingeditwidget.cpp  -  description
                             -------------------
    begin                : Sat Nov 6 1999
    copyright            : (C) 1999 by Falk Brettschneider
    email                : gigafalk@geocities.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "tabprocessingeditwidget.h"

TabProcessingEditWidget::TabProcessingEditWidget(QWidget* parent, const char* name) : QMultiLineEdit( parent, name)
{
   setFocusPolicy(QWidget::ClickFocus);
}

TabProcessingEditWidget::~TabProcessingEditWidget()
{
}

bool TabProcessingEditWidget::event( QEvent *e )
{
   if ( e->type() == QEvent::KeyPress ){
      QKeyEvent *k = (QKeyEvent *)e;
      if ( k->key() == Key_Tab ){
         keyPressEvent( k );
         return true;
      }
   }
   return QWidget::event( e );
}

void TabProcessingEditWidget::keyPressEvent(QKeyEvent *ke)
{
   if( ke->key() == Key_Tab) {
      insert("	");
      return;
   }
   insert( ke->text());

   ke->ignore();
}
