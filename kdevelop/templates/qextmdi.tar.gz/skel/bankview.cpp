#include <qpushbutton.h>
#include <qlayout.h>

#include "|NAMELITTLE|view.h"

|NAME|View::|NAME|View(QWidget *parent, |NAME|Doc *doc, QString title) : QextMdiChildView( title, parent)
   ,tew(0L)
{
   QVBoxLayout* vb = new QVBoxLayout(this);
   setFocusPolicy(QWidget::NoFocus);	

   tew = new TabProcessingEditWidget( this, "tab_processing_edit_widget");
   tew->setText(tr("This is a QLineEdit widget within a QextMDI view.\n\n") +
                tr("You can also load any text file in a new view by using 'FileOpen'\n") +
                tr("but this example is not able to save changes to file."));
   vb->addWidget(tew);

   QHBoxLayout* hb = new QHBoxLayout(vb);
   QPushButton *b1 = new QPushButton( "Test 1", this, "button_test1");
   b1->setFocusPolicy(StrongFocus);
   hb->addWidget(b1);
   QPushButton *b2 = new QPushButton( "Test 2", this, "button_test2");
   b2->setFocusPolicy(StrongFocus);
   hb->addWidget(b2);

   /** connect doc with the view*/
   QObject::connect(doc, SIGNAL(documentChanged()), this, SLOT(slotDocumentChanged()));

//test it:  setFixedHeight(200);
//test it:  setMaximumWidth(500);
}

|NAME|View::~|NAME|View()
{
}

void |NAME|View::slotDocumentChanged()
{
   //TODO update the view

}
