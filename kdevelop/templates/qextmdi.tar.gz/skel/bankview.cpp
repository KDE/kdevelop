#include <qpushbutton.h>

#include "tabprocessingeditwidget.h"
#include "|NAMELITTLE|view.h"

|NAME|View::|NAME|View(QWidget *parent, |NAME|Doc *doc, QString title) : QextMdiChildView( title, parent)
{
   setFocusPolicy(QWidget::NoFocus);	

   /* TabProcessingEditWidget is an example for a selfmade QT widget.
   */
   TabProcessingEditWidget *t = new TabProcessingEditWidget( this, "tab_processing_edit_widget");
   t->setGeometry( 10, 10, 280, 50);

   QPushButton *b1 = new QPushButton( "Test 1", this, "button_test1");
   b1->setGeometry( 10, 70, 100, 50);
   b1->setFocusPolicy(StrongFocus);

   QPushButton *b2 = new QPushButton( "Test 2", this, "button_test2");
   b2->setGeometry( 120, 70, 100, 50);
   b2->setFocusPolicy(StrongFocus);

  /** connect doc with the view*/
  QObject::connect(doc, SIGNAL(documentChanged()), this, SLOT(slotDocumentChanged()));
}

|NAME|View::~|NAME|View()
{
}

void |NAME|View::slotDocumentChanged()
{
  //TODO update the view

}
