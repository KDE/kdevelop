
#ifndef |NAMEBIG|VIEW_H
#define |NAMEBIG|VIEW_H

// include files for QT
#include <qwidget.h>

// application specific includes
#include "|NAMELITTLE|doc.h"

/**
 * This class provides an incomplete base for your application view. 
 */

class |NAME|View : public QWidget
{
  Q_OBJECT
  public:
    |NAME|View(QWidget *parent=0, |NAME|Doc* doc=0);
    ~|NAME|View();
  
  protected slots:
    void slotDocumentChanged();
  
};

#endif
