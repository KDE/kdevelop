#include "|NAMELITTLE|.h"

|NAME|::|NAME|(QWidget *parent, const char *name):KCModule(parent,name)
{
        QBoxLayout *top = new QVBoxLayout(this);
        load();
};


|NAME|::~|NAME|() {
}


void |NAME|::load() {
        // insert your loading code here...
}

void |NAME|::defaults() {
        // insert your default settings code here...
	emit changed(true);
}

void |NAME|::save() {
        // insert your saving code here...
	emit changed(true);
}

int |NAME|::buttons () {
        return KCModule::Default|KCModule::Apply|KCModule::Help;
}

void |NAME|::configChanged() {
        // insert your saving code here...
        emit changed(true);
}

QString |NAME|::quickHelp() const
{
         return i18n("Helpful information about the |NAMELITTLE| module."); }

void |NAME|::showInfo(const QString& protocol)
{
};


extern "C"
{

        KCModule *create_|NAME|(QWidget *parent, const char *name)
        {
                KGlobal::locale()->insertCatalogue("|NAME|");
                return new |NAME|(parent, name);
        }
}

#include "|NAMELITTLE|.moc"
