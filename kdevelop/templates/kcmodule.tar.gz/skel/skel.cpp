#include "|LITTLENAME|.h"

KCM|LITTLENAME|::KCM|LITTLENAME|(QWidget *parent, const char *name)
:KCModule(parent,name)
{
        QBoxLayout *top = new QVBoxLayout(this);
        load();
};


KCM|LITTLENAME|::~KCM|LITTLENAME|() {
}


void KCM|LITTLENAME|::load() {
        // insert your loading code here...
}

void KCM|LITTLENAME|::defaults() {
        // insert your default settings code here...
	emit changed(true);
}

void KCM|LITTLENAME|::save() {
        // insert your saving code here...
	emit changed(true);
}

int KCM|LITTLENAME|::buttons () {
        return KCModule::Default|KCModule::Apply|KCModule::Help;
}

void KCM|LITTLENAME|::configChanged() {
        // insert your saving code here...
        emit changed(true);
}

QString KCM|LITTLENAME|::quickHelp() const
{
         return i18n("Helpful information about the |NAMELITTLE| module.");
}

void KCM|LITTLENAME|::showInfo(const QString& protocol)
{
};


extern "C"
{

        KCModule *create_|LITTLENAME|(QWidget *parent, const char *name)
        {
                KGlobal::locale()->insertCatalogue("KCM|LITTLENAME|");
                return new KCM|LITTLENAME|(parent, name);
        }
}

#include "|LITTLENAME|.moc"
