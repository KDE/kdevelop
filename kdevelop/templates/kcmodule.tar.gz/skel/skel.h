#include <kcmodule.h>

class KCMIOSlaveInfo : public KCModule
{
   Q_OBJECT
   public:
      KCM|LITTLENAME|(QWidget *parent = 0L, const char *name = 0L);
      virtual ~KCM|LITTLENAME|();

      void load();
      void save();
      void defaults();
      int buttons();


   public slots:
      void configChanged();

   private:
};
