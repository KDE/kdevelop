#ifndef |NAMEBIG|_H_
#define |NAMEBIG|_H_
#endif
#include <kcmodule.h>

class |NAME|: public KCModule
{
   Q_OBJECT
   public:
      |NAME|(QWidget *parent = 0L, const char *name = 0L);
      virtual ~|NAME|();

      void load();
      void save();
      void defaults();
      int buttons();


   public slots:
      void configChanged();

   private:
};
