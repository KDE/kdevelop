#ifndef |NAMEBIG|_H_
#define |NAMEBIG|_H_

#include <kcmodule.h>
#include <kaboutdata.h>

class |NAME|: public KCModule
{
   Q_OBJECT
   public:
      |NAME|(QWidget *parent = 0L, const char *name = 0L);
      virtual ~|NAME|();

      void load();
      void save();
      void defaults();
      int buttons();
      QString quickHelp() const;
      const KAboutData* aboutData() {return myAboutData; };

   public slots:
      void configChanged();

   private:
      KAboutData *myAboutData;
};

#endif
