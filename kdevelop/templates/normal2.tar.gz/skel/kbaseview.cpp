
// include files for Qt
#include <qprinter.h>
#include <qpainter.h>

// application specific includes
#include "|NAMELITTLE|view.h"
#include "|NAMELITTLE|doc.h"
#include "|NAMELITTLE|.h"

|NAME|View::|NAME|View(QWidget *parent, const char *name) : QWidget(parent, name)
{
  setBackgroundMode(PaletteBase);
}

|NAME|View::~|NAME|View()
{
}

|NAME|Doc *|NAME|View::getDocument() const
{
  |NAME|App *theApp=(|NAME|App *) parentWidget();

  return theApp->getDocument();
}

void |NAME|View::print(QPrinter *pPrinter)
{
  QPainter printpainter;
  printpainter.begin(pPrinter);
	
  // TODO: add your printing code here

  printpainter.end();
}
