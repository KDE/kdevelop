
#include <kcmdlineargs.h>
#include <kaboutdata.h>
#include <klocale.h>

#include "|NAMELITTLE|.h"

static const char *description =
	I18N_NOOP("|NAME|");
// INSERT A DESCRIPTION FOR YOUR APPLICATION HERE
	
	
static KCmdLineOptions options[] =
{
  { "+[File]", I18N_NOOP("file to open"), 0 },
  { 0, 0, 0 }
  // INSERT YOUR COMMANDLINE OPTIONS HERE
};

int main(int argc, char *argv[])
{

	KAboutData aboutData( "|NAMELITTLE|", I18N_NOOP("|NAME|"),
		VERSION, description, KAboutData::License_GPL,
		"(c) |YEAR|, |AUTHOR|");
	aboutData.addAuthor("|AUTHOR|",0, "|EMAIL|");
	KCmdLineArgs::init( argc, argv, &aboutData );
	KCmdLineArgs::addCmdLineOptions( options ); // Add our own options.

  KApplication app;
 
  if (app.isRestored())
  {
    RESTORE(|NAME|App);
  }
  else 
  {
    |NAME|App *|NAMELITTLE| = new |NAME|App();
    |NAMELITTLE|->show();

    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();
		
		if (args->count())
		{
        |NAMELITTLE|->openDocumentFile(args->arg(0));
		}
		else
		{
		  |NAMELITTLE|->openDocumentFile();
		}
		args->clear();
  }

  return app.exec();
}  
