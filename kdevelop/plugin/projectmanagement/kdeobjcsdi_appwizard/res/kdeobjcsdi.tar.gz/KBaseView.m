
// include files for Qt
#include <qprinter.h>
#include <qpainter.h>

// application specific includes
#include "|APPHEADER|"
#include "|VIEWHEADER|"
#include "|DOCHEADER|"

|VIEWCLASS|::|VIEWCLASS|(QWidget *parent, const char *name) : QWidget(parent, name)
{
  setBackgroundMode(PaletteBase);
}

|VIEWCLASS|::~|VIEWCLASS|()
{
}

|DOCCLASS| *|VIEWCLASS|::getDocument() const
{
  |APPCLASS| *theApp=(|APPCLASS| *) parentWidget();

  return theApp->getDocument();
}

void |VIEWCLASS|::print(QPrinter *pPrinter)
{
  QPainter printpainter;
  printpainter.begin(pPrinter);
	
  // TODO: add your printing code here

  printpainter.end();
}
