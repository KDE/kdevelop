
// include files for Qt
#include <qdir.h>
#include <qwidget.h>

// include files for KDE
#include <klocale.h>
#include <kmessagebox.h>
#include <kio/job.h>
#include <kio/netaccess.h>

// application specific includes
#include "|APPHEADER|"
#include "|VIEWHEADER|"
#include "|DOCHEADER|"


QList<|NAME|View> *|DOCCLASS|::pViewList = 0L;

|DOCCLASS|::|DOCCLASS|(QWidget *parent, const char *name) : QObject(parent, name)
{
  if(!pViewList)
  {
    pViewList = new QList<|VIEWCLASS|>();
  }

  pViewList->setAutoDelete(true);
}

|DOCCLASS|::~|DOCCLASS|()
{
}

void |DOCCLASS|::addView(|VIEWCLASS| *view)
{
  pViewList->append(view);
}

void |DOCCLASS|::removeView(|VIEWCLASS| *view)
{
  pViewList->remove(view);
}
void |DOCCLASS|::setURL(const KURL &url)
{
  doc_url=url;
}

const KURL& |DOCCLASS|::URL() const
{
  return doc_url;
}

void |DOCCLASS|::slotUpdateAllViews(|VIEWCLASS| *sender)
{
  |VIEWCLASS| *w;
  if(pViewList)
  {
    for(w=pViewList->first(); w!=0; w=pViewList->next())
    {
      if(w!=sender)
        w->repaint();
    }
  }

}

bool |DOCCLASS|::saveModified()
{
  bool completed=true;

  if(modified)
  {
    |APPCLASS| *win=(|APPCLASS| *) parent();
    int want_save = KMessageBox::warningYesNoCancel(win, i18n("Warning"),
                                         i18n("The current file has been modified.\n"
                                              "Do you want to save it?"));
    switch(want_save)
    {
      case 1:
           if (doc_url.fileName() == i18n("Untitled"))
           {
             win->slotFileSaveAs();
           }
           else
           {
             saveDocument(URL());
       	   };

       	   deleteContents();
           completed=true;
           break;

      case 2:
           setModified(false);
           deleteContents();
           completed=true;
           break;	

      case 3:
           completed=false;
           break;

      default:
           completed=false;
           break;
    }
  }

  return completed;
}

void |DOCCLASS|::closeDocument()
{
  deleteContents();
}

bool |DOCCLASS|::newDocument()
{
  /////////////////////////////////////////////////
  // TODO: Add your document initialization code here
  /////////////////////////////////////////////////
  modified=false;
  doc_url.setFileName(i18n("Untitled"));

  return true;
}

bool |DOCCLASS|::openDocument(const KURL& url, const char *format /*=0*/)
{
  QString tmpfile;
  KIO::NetAccess::download( url, tmpfile );
  /////////////////////////////////////////////////
  // TODO: Add your document opening code here
  /////////////////////////////////////////////////

  KIO::NetAccess::removeTempFile( tmpfile );

  modified=false;
  return true;
}

bool |DOCCLASS|::saveDocument(const KURL& url, const char *format /*=0*/)
{
  /////////////////////////////////////////////////
  // TODO: Add your document saving code here
  /////////////////////////////////////////////////

  modified=false;
  return true;
}

void |DOCCLASS|::deleteContents()
{
  /////////////////////////////////////////////////
  // TODO: Add implementation to delete the document contents
  /////////////////////////////////////////////////

}
